// The video player in the in-page modal (embed=1) and in a popup window. It plays
// the storyboard live, as the storyboard's Play does: slides drawn here, narration
// from the PageCast server (fresh short-lived links each time it opens). An
// exported MP4, if there is one, is offered as Download; a video exported before
// the live player existed plays as a plain video.
import { api, userMessage } from './lib/api.js';
import { followNarration } from './lib/narration.js';
import { DeckPlayer } from './shared/deck-player.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const embedded = params.get('embed') === '1';
const key = params.get('video') || 'last';
let meta = null;
let video = null;
let player = null;
let stopFollowing = () => {};

function msg(text) {
  $('msg').textContent = text || '';
  $('msg').classList.toggle('hidden', !text);
}

async function findMeta() {
  const { lastVideo, videos } = await chrome.storage.local.get(['lastVideo', 'videos']);
  if (key === 'last') return lastVideo;
  return videos?.[key] || (lastVideo?.jobKey === key ? lastVideo : null);
}

function showDeck(n, assets) {
  $('deck').classList.remove('hidden');
  player = new DeckPlayer($('deck'), {
    cssHref: chrome.runtime.getURL('shared/slides.css'),
    img: (id) => (id ? assets[id] || null : null),
  });
  player.load(n.deck, n.slides, { speed: n.speed });
  $('deck').focus();
  if (n.slides.some((s) => s.pending)) {
    $('meta').textContent = 'Narrating…';
    stopFollowing = followNarration(meta.apiJobId, (latest) => {
      if (latest.runId !== n.runId) return;
      player.update(latest.slides);
      if (!latest.slides.some((s) => s.pending)) $('meta').textContent = '';
    });
  }
}

function showVideo() {
  const v = $('video');
  v.classList.remove('hidden');
  v.src = video.url;
}

async function load() {
  meta = await findMeta();
  if (!meta?.apiJobId) {
    msg('No video found. Make one from the PageCast popup first.');
    return;
  }
  $('title').textContent = meta.title || 'PageCast video';
  document.title = `${meta.title || 'Video'} · PageCast`;
  $('storyboard').disabled = !meta.jobKey;
  let job;
  try {
    job = await api.getJob(meta.apiJobId, ['narration', 'assets']);
  } catch (e) {
    msg(e.status === 404 ? 'This video has expired. Make it again from the PageCast popup.' : userMessage(e, "Couldn't load the video. Try again."));
    return;
  }
  video = job.video?.url ? job.video : null;
  $('download').classList.toggle('hidden', !video);
  if (job.narration) {
    msg('');
    showDeck(job.narration, job.assets || {});
  } else if (video) {
    msg('');
    showVideo();
  } else {
    msg('This video is no longer available. Open the storyboard and press Play to make it again.');
  }
}

$('download').addEventListener('click', async () => {
  try {
    // a fresh link: the one from when the player opened may have expired
    const fresh = (await api.getJob(meta.apiJobId)).video || video;
    chrome.downloads.download({ url: fresh.url, filename: fresh.filename || 'pagecast.mp4', saveAs: true });
  } catch (e) {
    msg(userMessage(e));
  }
});
$('storyboard').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'openStoryboard', jobKey: meta.jobKey }));

function close() {
  stopFollowing();
  player?.pause();
  $('video').pause();
  if (embedded) parent.postMessage('pagecast:close', '*');
  else window.close();
}
$('close').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !document.fullscreenElement) close();
});

if (embedded) parent.postMessage('pagecast:ready', '*');
load().catch((e) => msg(userMessage(e, "Couldn't load the video. Try again.")));
