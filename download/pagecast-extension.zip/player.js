// Video player, used inside the in-page modal (embed=1), in a popup window, and
// reusable from the storyboard. The video lives on the PageCast server; each time
// the player opens it asks the API for a fresh (short-lived) link to it.
import { api, userMessage } from './lib/api.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const embedded = params.get('embed') === '1';
const key = params.get('video') || 'last';
let meta = null;
let video = null;

function msg(text) {
  $('msg').textContent = text || '';
  $('msg').classList.toggle('hidden', !text);
}

function fmtDur(s) {
  const m = Math.floor(s / 60);
  return `${m}:${String(Math.round(s % 60)).padStart(2, '0')}`;
}

async function findMeta() {
  const { lastVideo, videos } = await chrome.storage.local.get(['lastVideo', 'videos']);
  if (key === 'last') return lastVideo;
  return videos?.[key] || (lastVideo?.jobKey === key ? lastVideo : null);
}

async function load() {
  meta = await findMeta();
  if (!meta?.apiJobId) {
    msg('No video found. Make one from the PageCast popup first.');
    return;
  }
  $('title').textContent = meta.title || 'PageCast video';
  document.title = `${meta.title || 'Video'} · PageCast`;
  $('storyboard').disabled = !meta.jobKey;
  try {
    video = (await api.getJob(meta.apiJobId)).video;
  } catch (e) {
    msg(e.status === 404 ? 'This video has expired. Videos are kept for 30 days.' : userMessage(e, "Couldn't load the video. Try again."));
    return;
  }
  if (!video?.url) {
    msg('This video is no longer available. Render it again from the storyboard.');
    return;
  }
  const v = $('video');
  v.src = video.url;
  $('meta').textContent = [video.duration ? fmtDur(video.duration) : '', video.size ? `${(video.size / 1e6).toFixed(1)} MB` : ''].filter(Boolean).join(' · ');
  $('download').disabled = false;
  msg('');
  v.play().catch(() => {}); // autoplay may need a click; controls are there
}

$('download').addEventListener('click', () => {
  chrome.downloads.download({ url: video.url, filename: video.filename || 'pagecast.mp4', saveAs: true });
});
$('storyboard').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'openStoryboard', jobKey: meta.jobKey }));

function close() {
  $('video').pause();
  if (embedded) parent.postMessage('pagecast:close', '*');
  else window.close();
}
$('close').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') close();
});

if (embedded) parent.postMessage('pagecast:ready', '*');
load().catch((e) => msg(userMessage(e, "Couldn't load the video. Try again.")));
