// Storyboard page: runs filter -> images -> draft through the PageCast API, lets
// the user edit every slide against a live preview, then plays it: the server only
// speaks the narration, and the player here draws the slides (Play). Export video
// renders an MP4 in the cloud for downloading. Each step runs on the
// server; this page starts it and polls, so a reload picks up where it left off.
import { api, upload, runStep, userMessage, ApiError } from './lib/api.js';
import { currentBackend } from './lib/config.js';
import { db } from './lib/db.js';
import { loadSettings, saveSettings } from './lib/settings.js';
import { LAYOUTS, LAYOUT_NAMES, slideHTML, fitSlide } from './shared/slides.js';
import { DeckPlayer } from './shared/deck-player.js';
import { startNarration, followNarration } from './lib/narration.js';
import { consentHTML, giveConsent, hasConsent } from './lib/consent.js';

const $ = (id) => document.getElementById(id);
const jobKey = new URLSearchParams(location.search).get('job');
let job = null;
let settings = await loadSettings();
const imgURLs = new Map(); // imageId -> object URL for previews
let busy = null; // name of the running step, for cancel

const WPS = 2.5; // spoken words per second at 1x (150 wpm)
// what the API accepts as an image upload
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif', 'image/svg+xml']);
const CATEGORY_LABELS = {
  ad: 'Ads', sponsored: 'Sponsored', nav: 'Navigation', promo: 'Promotions', newsletter: 'Newsletter prompts',
  cookie: 'Cookie banners', social: 'Social / share', related: 'Related stories', comments: 'Comments',
  footer: 'Footer', 'author-bio': 'Author bio', login: 'Login / paywall', 'off-topic': 'Off-topic', other: 'Other',
};

// ================================================================ utilities
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const words = (s) => String(s || '').split(/\s+/).filter(Boolean).length;
const clip = (s, n) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s));
function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}
const saveJob = debounce(() => db.put('jobs', jobKey, job), 400);
const saveJobNow = () => db.put('jobs', jobKey, job);

function step(name, state) {
  const li = document.querySelector(`#steps li[data-step="${name}"]`);
  if (!li) return;
  li.classList.toggle('active', state === 'active');
  li.classList.toggle('done', state === 'done');
}

function working(title, text = '', fraction = null) {
  $('working').classList.remove('hidden');
  document.querySelector('#working .spinner').classList.remove('hidden');
  $('workTitle').textContent = title;
  $('workText').textContent = text;
  const bar = $('workBar').parentElement;
  bar.classList.remove('hidden');
  bar.classList.toggle('indeterminate', fraction == null);
  $('workBar').style.width = fraction == null ? '' : `${Math.round(fraction * 100)}%`;
}

/** A step stopped with an error: no spinner or progress bar left running under the message. */
function stalled() {
  document.querySelector('#working .spinner').classList.add('hidden');
  $('workBar').parentElement.classList.add('hidden');
  $('workTitle').textContent = 'Stopped';
  $('workText').textContent = 'Nothing more will happen until you try again.';
  $('cancelWork').classList.add('hidden');
}

function banner(msg, retry) {
  const b = $('banner');
  if (!msg) {
    b.classList.add('hidden');
    return;
  }
  b.innerHTML = `<strong>Something went wrong.</strong> ${esc(msg)} ${retry ? '<button class="btn small" type="button" id="retry">Try again</button>' : ''}`;
  b.classList.remove('hidden');
  if (retry) $('retry').onclick = () => {
    banner('');
    retry();
  };
}

// The server-side job for this storyboard. It's created on first run (the page
// goes straight to storage), and again if the server has since expired it.
async function ensureServerJob() {
  if (job.apiJobId) {
    try {
      await api.getJob(job.apiJobId);
      return;
    } catch (e) {
      if (e.status !== 404) throw e;
      // expired on the server: start over there; the local edits are kept
      job.filter = null;
    }
  }
  working('Uploading the page…', 'Sending the page text to PageCast.');
  const body = new Blob([JSON.stringify(job.page)], { type: 'application/json' });
  const created = await api.createJob({
    title: clip(job.title || '', 500),
    url: String(job.url || '').slice(0, 4000),
    guidance: clip(job.guidance || '', 2000),
    minutes: job.settings.minutes,
    pageBytes: body.size,
  });
  await upload(created.pageUpload, body);
  job.apiJobId = created.jobId;
  job.uploaded = [];
  await saveJobNow();
}

/** Which AI the server writes with, for the source panel (the server says). */
async function engineName() {
  const model = await api.health().then((h) => String(h.model || ''), () => '');
  if (model.startsWith('claude-')) return 'Claude';
  if (model.includes('glm-')) return 'GLM 5.3 Flash';
  return 'AI';
}

// ================================================================ pipeline
/**
 * The popup asks before anything is sent; this catches a storyboard opened some
 * other way (an older job, a bookmarked link). Nothing is uploaded until people agree.
 */
function askConsent() {
  document.querySelector('#working .spinner').classList.add('hidden');
  $('workBar').parentElement.classList.add('hidden');
  $('workTitle').textContent = 'One thing first';
  $('workText').textContent = '';
  const box = document.createElement('div');
  box.className = 'consent';
  box.innerHTML = `${consentHTML()}<div class="consent-actions"><button class="btn primary" type="button">I agree, continue</button></div>`;
  $('workText').after(box);
  return new Promise((resolve) => {
    box.querySelector('button').addEventListener('click', async () => {
      await giveConsent();
      box.remove();
      document.querySelector('#working .spinner').classList.remove('hidden');
      $('workBar').parentElement.classList.remove('hidden');
      resolve();
    });
  });
}

async function run() {
  job = await db.get('jobs', jobKey);
  if (!job) {
    working('Storyboard not found', 'This storyboard has expired. Start again from the PageCast popup.');
    $('workBar').parentElement.classList.add('hidden');
    document.querySelector('.spinner').classList.add('hidden');
    return;
  }
  job.restored ||= [];
  job.uploaded ||= [];
  document.title = `${clip(job.title || 'Storyboard', 50)} · PageCast`;
  $('sourceLink').textContent = job.title || job.url;
  $('sourceLink').href = job.url;
  $('engine').textContent = `Made with ${await engineName()} · ${(await currentBackend()).label}`;
  step('read', 'done');

  await restoreImageURLs();
  try {
    if (!(await hasConsent())) await askConsent();
    await ensureServerJob();
    if (!job.filter) await runFilter();
    else {
      step('filter', 'done');
      renderFiltered();
    }
    await collectImages();
    if (!job.deck) await runDraft();
    else step('draft', 'done');
    showEditor();
  } catch (e) {
    busy = null;
    $('cancelWork').classList.add('hidden');
    if (e.cancelled) {
      working('Cancelled', 'Nothing more will happen until you try again.', 0);
      banner('Cancelled.', () => run());
    } else {
      stalled();
      banner(userMessage(e), () => run());
    }
  }
}

async function runFilter() {
  step('filter', 'active');
  working('Filtering out clutter…', 'The AI is sorting real content from ads, menus and other page furniture.');
  busy = 'filter';
  $('cancelWork').classList.remove('hidden');
  await runStep(job.apiJobId, 'filter', {}, (p) =>
    working('Filtering out clutter…', p.text || 'The AI is sorting real content from ads and menus.', p.fraction ?? null),
  );
  busy = null;
  $('cancelWork').classList.add('hidden');
  job.filter = (await api.getJob(job.apiJobId, ['filter'])).filter;
  await saveJobNow();
  step('filter', 'done');
  renderFiltered();
}

function keptImages() {
  const labels = job.filter?.labels || {};
  const restored = new Set(job.restored);
  return job.page.images.filter((im) => restored.has(im.id) || labels[im.id]?.keep !== false);
}

// ---------------------------------------------------------------- images
// Images are fetched here in the browser (so images behind the user's logins
// load), kept in IndexedDB for the previews, and uploaded to presigned URLs.
async function fetchImage(im) {
  const cached = await db.get('blobs', `${jobKey}/${im.id}`);
  if (cached) return cached;
  let blob = null;
  // without cookies first (most images are public, and that avoids sending
  // cookies to third parties); with cookies only when that fails
  for (const credentials of ['omit', 'include']) {
    try {
      const r = await fetch(im.src, { credentials, referrer: job.url, referrerPolicy: 'no-referrer-when-downgrade' });
      if (r.ok) {
        blob = await r.blob();
        break;
      }
    } catch {}
  }
  // some images only load with the page's own cookies/referrer: fetch from the tab
  if ((!blob || !blob.type.startsWith('image/')) && job.tabId) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: job.tabId },
        func: async (src) => {
          const r = await fetch(src, { credentials: 'include' });
          if (!r.ok) return null;
          const b = await r.blob();
          return await new Promise((ok) => {
            const fr = new FileReader();
            fr.onload = () => ok(fr.result);
            fr.readAsDataURL(b);
          });
        },
        args: [im.src],
      });
      if (res?.result) blob = await (await fetch(res.result)).blob();
    } catch {}
  }
  if (!blob) return null;
  let type = blob.type.split(';')[0];
  if (!type.startsWith('image/')) {
    // servers that send application/octet-stream: sniff the common formats
    const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
    if (head[0] === 0xff && head[1] === 0xd8) type = 'image/jpeg';
    else if (head[0] === 0x89 && head[1] === 0x50) type = 'image/png';
    else if (head[8] === 0x57 && head[9] === 0x45) type = 'image/webp';
    else if (head[0] === 0x47 && head[1] === 0x49) type = 'image/gif';
    else return null;
  }
  if (!IMAGE_TYPES.has(type) || blob.size > 20 * 1024 * 1024) return null;
  if (blob.type !== type) blob = new Blob([blob], { type });
  await db.put('blobs', `${jobKey}/${im.id}`, blob);
  return blob;
}

async function restoreImageURLs() {
  for (const im of job.page.images) {
    const b = await db.get('blobs', `${jobKey}/${im.id}`);
    if (b) imgURLs.set(im.id, URL.createObjectURL(b));
  }
}

/** Uploads fetched images the server doesn't have yet. items: [{ im, blob }] */
async function uploadImages(items, onUploaded) {
  const todo = items.filter(({ im }) => !job.uploaded.includes(im.id));
  for (let i = 0; i < todo.length; i += 80) {
    const batch = todo.slice(i, i + 80);
    const { uploads } = await api.assets(job.apiJobId, batch.map(({ im, blob }) => ({ imageId: im.id, mime: blob.type, bytes: blob.size })));
    await Promise.all(
      uploads.map(async (u) => {
        await upload(u, batch.find((x) => x.im.id === u.imageId).blob);
        job.uploaded.push(u.imageId);
        onUploaded?.();
      }),
    );
  }
}

async function ensureImage(im) {
  const blob = await fetchImage(im);
  if (!blob) return false;
  if (!imgURLs.has(im.id)) imgURLs.set(im.id, URL.createObjectURL(blob));
  await uploadImages([{ im, blob }]);
  return true;
}

async function collectImages() {
  step('images', 'active');
  const list = keptImages().filter((im) => !job.uploaded.includes(im.id)).slice(0, 80);
  const fetched = [];
  let done = 0;
  let failed = 0;
  const queue = [...list];
  const worker = async () => {
    while (queue.length) {
      const im = queue.shift();
      const blob = await fetchImage(im).catch(() => null);
      if (blob) {
        fetched.push({ im, blob });
        if (!imgURLs.has(im.id)) imgURLs.set(im.id, URL.createObjectURL(blob));
      } else failed++;
      done++;
      working('Collecting images…', `${done} of ${list.length}${failed ? ` (${failed} couldn't be loaded)` : ''}`, done / Math.max(1, list.length));
    }
  };
  if (list.length) await Promise.all(Array.from({ length: 6 }, worker));
  if (fetched.length) {
    let sent = 0;
    working('Uploading images…', `0 of ${fetched.length}`, 0);
    await uploadImages(fetched, () => {
      sent++;
      working('Uploading images…', `${sent} of ${fetched.length}`, sent / fetched.length);
    });
  }
  await saveJobNow();
  step('images', 'done');
}

// ---------------------------------------------------------------- draft
async function runDraft({ note, previous } = {}) {
  step('draft', 'active');
  step('edit', null);
  $('slides').classList.add('hidden');
  $('addEnd').classList.add('hidden');
  setEditorEnabled(false);
  const title = previous ? 'Redrafting…' : 'Writing the storyboard…';
  working(title, 'The AI is planning the slides and narration.');
  busy = 'draft';
  $('cancelWork').classList.remove('hidden');
  try {
    await runStep(job.apiJobId, 'draft', { restored: job.restored, ...(note ? { note } : {}), ...(previous ? { previous } : {}) }, (p) =>
      working(title, p.text || 'Writing…', p.fraction ?? null),
    );
    job.deck = (await api.getJob(job.apiJobId, ['storyboard'])).storyboard;
    await saveJobNow();
    step('draft', 'done');
  } finally {
    busy = null;
    $('cancelWork').classList.add('hidden');
  }
}

$('cancelWork').addEventListener('click', () => api.cancel(job.apiJobId).catch(() => {}));

// ================================================================ filtered panel
function renderFiltered() {
  const labels = job.filter?.labels || {};
  const items = [...job.page.blocks, ...job.page.images].filter((it) => labels[it.id]?.keep === false);
  $('filteredPanel').classList.remove('hidden');
  $('filteredCount').textContent = `${items.length} items`;
  const groups = new Map();
  for (const it of items) {
    const cat = labels[it.id].category || 'other';
    (groups.get(cat) || groups.set(cat, []).get(cat)).push(it);
  }
  const restored = new Set(job.restored);
  $('filteredList').innerHTML = [...groups.entries()]
    .sort((a, b) => b[1].length - a[1].length)
    .map(
      ([cat, list]) => `
      <details>
        <summary><span>${esc(CATEGORY_LABELS[cat] || cat)}</span><span class="muted">${list.length}</span></summary>
        <div class="items">
          ${list
            .map((it) => {
              const isImg = it.id.startsWith('i');
              const text = isImg ? it.alt || it.caption || 'Image' : it.text || (it.items || []).join(' · ') || (it.rows || []).map((r) => r.join(' | ')).join(' / ');
              return `<label class="f-item">
                <input type="checkbox" data-id="${it.id}" ${restored.has(it.id) ? 'checked' : ''} aria-label="Restore this item">
                <span>${isImg ? `<img src="${esc(it.src)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ''}<span class="t">${esc(clip(text, 160))}</span><br><span class="r">${esc(labels[it.id].reason || '')}</span></span>
              </label>`;
            })
            .join('')}
        </div>
      </details>`,
    )
    .join('');
  updateRestoredButton();
}

$('filteredList').addEventListener('change', (e) => {
  const id = e.target.dataset?.id;
  if (!id) return;
  const set = new Set(job.restored);
  e.target.checked ? set.add(id) : set.delete(id);
  job.restored = [...set];
  saveJob();
  updateRestoredButton();
});

function updateRestoredButton() {
  const n = job.restored.length;
  $('redraftRestored').classList.toggle('hidden', !n || !job.deck);
  $('redraftRestored').textContent = `Redraft with ${n} restored item${n === 1 ? '' : 's'}`;
}

$('redraftRestored').addEventListener('click', () =>
  redraft('Some content that was filtered out has been restored by the user; work it into the storyboard where it fits.'),
);
$('redraft').addEventListener('click', () => {
  const note = $('note').value.trim();
  if (!note) {
    $('note').focus();
    return;
  }
  redraft(note);
});

async function redraft(note) {
  banner('');
  try {
    await collectImages(); // restored images need uploading first
    await runDraft({ note, previous: job.deck });
    $('note').value = '';
    showEditor();
  } catch (e) {
    showEditor();
    banner(e.cancelled ? 'Redraft cancelled; your previous storyboard is unchanged.' : userMessage(e));
  }
}

// ================================================================ editor
function setEditorEnabled(on) {
  for (const id of ['deckTitle', 'accent', 'voice', 'speed', 'render', 'play', 'redraft']) $(id).disabled = !on;
}

function showEditor() {
  $('working').classList.add('hidden');
  $('slides').classList.remove('hidden');
  $('addEnd').classList.remove('hidden');
  $('redraftPanel').classList.remove('hidden');
  step('edit', 'active');
  setEditorEnabled(true);
  $('deckTitle').value = job.deck.title || '';
  $('accent').value = /^#[0-9a-f]{6}$/i.test(job.deck.accent) ? job.deck.accent : '#d9531e';
  $('speed').value = String(job.settings.speed ?? settings.speed);
  loadVoices();
  renderSlides();
  updateRestoredButton();
}

async function loadVoices() {
  if ($('voice').options.length) return;
  try {
    const voices = await api.voices();
    $('voice').innerHTML = voices.map((v) => `<option value="${v.id}">${esc(v.label)}</option>`).join('');
  } catch {
    $('voice').innerHTML = `<option value="af_heart">Heart (US, female)</option>`;
  }
  $('voice').value = job.settings.voice || settings.voice;
}

$('deckTitle').addEventListener('input', () => {
  job.deck.title = $('deckTitle').value;
  saveJob();
  refreshAllPreviews();
});
$('accent').addEventListener('input', () => {
  job.deck.accent = $('accent').value;
  saveJob();
  refreshAllPreviews();
});
$('voice').addEventListener('change', async () => {
  job.settings.voice = $('voice').value;
  saveJob();
  settings = await saveSettings({ voice: job.settings.voice });
});
$('speed').addEventListener('change', async () => {
  job.settings.speed = Number($('speed').value);
  saveJob();
  updateStats();
  settings = await saveSettings({ speed: job.settings.speed });
});

function slideSeconds(s) {
  const w = words(s.narration);
  return Math.max(3, 1.4 + w / (WPS * (job.settings.speed || 1)));
}

function updateStats() {
  const slides = job.deck.slides;
  const total = slides.reduce((n, s) => n + slideSeconds(s), 0) - 0.5 * Math.max(0, slides.length - 1);
  const w = slides.reduce((n, s) => n + words(s.narration), 0);
  $('stats').textContent = `${slides.length} slides · ${w} words · ~${Math.floor(total / 60)}:${String(Math.round(total % 60)).padStart(2, '0')}`;
}

const img = (id) => (id ? imgURLs.get(id) || null : null);
const deckInfo = () => ({ title: job.deck.title, accent: job.deck.accent, siteName: job.deck.siteName, url: job.deck.url });

function renderSlides() {
  const ol = $('slides');
  ol.innerHTML = '';
  job.deck.slides.forEach((s, i) => ol.appendChild(buildCard(s, i)));
  updateStats();
}

function field(label, html) {
  return `<label class="field"><span>${label}</span>${html}</label>`;
}

function fieldsHTML(s) {
  const f = LAYOUTS[s.layout]?.fields || [];
  const out = [];
  const input = (k, ph = '') => `<input class="input" data-k="${k}" value="${esc(s[k] || '')}" placeholder="${esc(ph)}">`;
  const area = (k, rows = 2, ph = '') => `<textarea class="input" data-k="${k}" rows="${rows}" placeholder="${esc(ph)}">${esc(s[k] || '')}</textarea>`;
  if (f.includes('heading')) out.push(field('Heading', input('heading')));
  if (f.includes('subheading')) out.push(field('Subheading', input('subheading')));
  if (f.includes('stat')) out.push(`<div class="row">${field('Big number', input('stat', '73%'))}${field('Label', input('statLabel'))}</div>`);
  if (f.includes('quote')) out.push(field('Quote', area('quote', 3)));
  if (f.includes('attribution')) out.push(field('Attribution', input('attribution')));
  if (f.includes('bullets')) out.push(field('Bullets <em class="muted">(one per line)</em>', `<textarea class="input" data-k="bullets" rows="4">${esc((s.bullets || []).join('\n'))}</textarea>`));
  if (f.includes('body')) out.push(field('Body text', area('body', 2)));
  if (f.includes('columns')) {
    const c = s.columns || [];
    out.push(
      `<div class="row">${[0, 1]
        .map(
          (j) => `<div class="field"><span>Column ${j + 1}</span><input class="input" data-col="${j}" data-ck="heading" value="${esc(c[j]?.heading || '')}" placeholder="Heading">
          <textarea class="input" data-col="${j}" data-ck="bullets" rows="3" placeholder="One point per line">${esc((c[j]?.bullets || []).join('\n'))}</textarea></div>`,
        )
        .join('')}</div>`,
    );
  }
  if (f.includes('table')) {
    const t = s.table || { headers: [], rows: [] };
    const text = [t.headers.join(' | '), ...t.rows.map((r) => r.join(' | '))].join('\n');
    out.push(field('Table <em class="muted">(first line = headers, cells separated by |)</em>', `<textarea class="input" data-k="table" rows="5">${esc(text)}</textarea>`));
  }
  if (f.includes('code')) out.push(field('Code', `<textarea class="input mono" data-k="code" rows="6" spellcheck="false">${esc(s.code || '')}</textarea>`), field('Language', input('codeLang')));
  if (f.includes('imageId')) {
    const im = job.page.images.find((x) => x.id === s.imageId);
    out.push(`<div class="field"><span>Image</span><div class="img-pick">
      ${s.imageId && img(s.imageId) ? `<img class="thumb" src="${img(s.imageId)}" alt="${esc(im?.alt || '')}">` : '<div class="thumb"></div>'}
      <button class="btn small" type="button" data-act="pick">${s.imageId ? 'Change image' : 'Choose image'}</button>
      ${f.includes('imageFit') ? `<select class="input compact" data-k="imageFit" aria-label="Image fit"><option value="cover">Fill</option><option value="contain" ${s.imageFit === 'contain' ? 'selected' : ''}>Fit whole image</option></select>` : ''}
    </div></div>`);
  }
  if (f.includes('caption')) out.push(field('Caption', input('caption')));
  const w = words(s.narration);
  out.push(`<label class="field narr"><span>Narration <span class="count ${w > 110 ? 'long' : ''}">· ${w} words · ~${Math.round(slideSeconds(s))} s</span></span>
    <textarea class="input" data-k="narration" rows="4">${esc(s.narration || '')}</textarea></label>`);
  return out.join('');
}

function buildCard(s, i) {
  const li = document.createElement('li');
  li.className = 'card';
  li.innerHTML = `
    <div class="preview-col">
      <div class="preview"><iframe tabindex="-1" aria-hidden="true" title="Slide ${i + 1} preview"></iframe></div>
      <div class="card-tools">
        <span class="num">Slide ${i + 1}</span>
        <select class="input compact" data-act="layout" aria-label="Layout">${LAYOUT_NAMES.map((l) => `<option value="${l}" ${l === s.layout ? 'selected' : ''}>${LAYOUTS[l].label}</option>`).join('')}</select>
        <button class="btn small icon ghost" type="button" data-act="up" title="Move up" aria-label="Move up" ${i === 0 ? 'disabled' : ''}>↑</button>
        <button class="btn small icon ghost" type="button" data-act="down" title="Move down" aria-label="Move down" ${i === job.deck.slides.length - 1 ? 'disabled' : ''}>↓</button>
        <button class="btn small icon ghost" type="button" data-act="dup" title="Duplicate" aria-label="Duplicate">⧉</button>
        <button class="btn small icon ghost" type="button" data-act="del" title="Delete" aria-label="Delete">🗑</button>
      </div>
    </div>
    <div class="fields">${fieldsHTML(s)}</div>`;
  const frame = li.querySelector('iframe');
  frame.srcdoc = `<!doctype html><html><head><link rel="stylesheet" href="${chrome.runtime.getURL('shared/slides.css')}"><style>html,body{margin:0;overflow:hidden;background:#000}</style></head><body></body></html>`;
  frame.addEventListener('load', () => updatePreview(li, i), { once: true });
  scalePreview(li);
  return li;
}

const ro = new ResizeObserver((entries) => {
  for (const e of entries) {
    const f = e.target.querySelector('iframe');
    if (f) f.style.transform = `scale(${e.contentRect.width / 1920})`;
  }
});
function scalePreview(li) {
  ro.observe(li.querySelector('.preview'));
}

async function updatePreview(li, i) {
  const frame = li.querySelector('iframe');
  const doc = frame.contentDocument;
  if (!doc?.body) return;
  const s = job.deck.slides[i];
  doc.body.innerHTML = slideHTML(s, deckInfo(), { img, index: i, total: job.deck.slides.length });
  await doc.fonts?.ready;
  await Promise.all([...doc.images].map((im) => (im.complete ? null : new Promise((r) => (im.onload = im.onerror = r)))));
  fitSlide(doc);
}

function refreshAllPreviews() {
  [...$('slides').children].forEach((li, i) => updatePreview(li, i));
}

const cardIndex = (el) => [...$('slides').children].indexOf(el.closest('.card'));

$('slides').addEventListener('input', (e) => {
  const t = e.target;
  const i = cardIndex(t);
  if (i < 0) return;
  const s = job.deck.slides[i];
  const k = t.dataset.k;
  if (k === 'bullets') s.bullets = t.value.split('\n').map((x) => x.trim()).filter(Boolean);
  else if (k === 'table') {
    const lines = t.value.split('\n').filter((l) => l.trim());
    const cells = (l) => l.split('|').map((c) => c.trim());
    s.table = { headers: lines[0] ? cells(lines[0]) : [], rows: lines.slice(1).map(cells) };
  } else if (t.dataset.col != null) {
    s.columns ||= [{ heading: '', bullets: [] }, { heading: '', bullets: [] }];
    const col = s.columns[Number(t.dataset.col)] ||= { heading: '', bullets: [] };
    if (t.dataset.ck === 'heading') col.heading = t.value;
    else col.bullets = t.value.split('\n').map((x) => x.trim()).filter(Boolean);
  } else if (k) s[k] = t.value;
  else return;
  if (k === 'narration') {
    const c = t.closest('.narr').querySelector('.count');
    const w = words(s.narration);
    c.textContent = `· ${w} words · ~${Math.round(slideSeconds(s))} s`;
    c.classList.toggle('long', w > 110);
    updateStats();
  }
  saveJob();
  debouncedPreview(i);
});

const pendingPreviews = new Set();
const flushPreviews = debounce(() => {
  for (const i of pendingPreviews) {
    const li = $('slides').children[i];
    if (li) updatePreview(li, i);
  }
  pendingPreviews.clear();
}, 150);
function debouncedPreview(i) {
  pendingPreviews.add(i);
  flushPreviews();
}

$('slides').addEventListener('change', (e) => {
  const t = e.target;
  const i = cardIndex(t);
  if (i < 0) return;
  if (t.dataset.act === 'layout') {
    job.deck.slides[i].layout = t.value;
    const li = t.closest('.card');
    li.querySelector('.fields').innerHTML = fieldsHTML(job.deck.slides[i]);
    saveJob();
    updatePreview(li, i);
  } else if (t.dataset.k === 'imageFit') {
    job.deck.slides[i].imageFit = t.value;
    saveJob();
    updatePreview(t.closest('.card'), i);
  }
});

$('slides').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  const i = cardIndex(b);
  const slides = job.deck.slides;
  switch (b.dataset.act) {
    case 'up':
      [slides[i - 1], slides[i]] = [slides[i], slides[i - 1]];
      break;
    case 'down':
      [slides[i + 1], slides[i]] = [slides[i], slides[i + 1]];
      break;
    case 'dup':
      slides.splice(i + 1, 0, structuredClone(slides[i]));
      break;
    case 'del':
      if (slides.length <= 1) return;
      if (!confirm(`Delete slide ${i + 1}?`)) return;
      slides.splice(i, 1);
      break;
    case 'pick':
      openGallery(i);
      return;
    default:
      return;
  }
  saveJob();
  renderSlides();
});

$('addSlide').addEventListener('click', () => {
  job.deck.slides.push({ layout: 'bullets', heading: 'New slide', bullets: ['First point'], narration: '' });
  saveJob();
  renderSlides();
  $('slides').lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'center' });
});

// ---------------------------------------------------------------- gallery
let galleryFor = -1;
function openGallery(i) {
  galleryFor = i;
  renderGallery();
  $('gallery').showModal();
}
function renderGallery() {
  const labels = job.filter?.labels || {};
  const all = $('galAll').checked;
  const kept = new Set(keptImages().map((x) => x.id));
  const list = job.page.images.filter((im) => kept.has(im.id) || all);
  const cur = job.deck.slides[galleryFor]?.imageId;
  $('galGrid').innerHTML =
    list
      .map((im) => {
        const src = imgURLs.get(im.id) || im.src;
        const filtered = !kept.has(im.id);
        return `<button type="button" class="gal-item ${im.id === cur ? 'selected' : ''} ${filtered ? 'filtered-img' : ''}" data-id="${im.id}">
          <img src="${esc(src)}" alt="" loading="lazy" referrerpolicy="no-referrer">
          <span class="cap">${esc(im.alt || im.caption || im.near || im.id)}</span>
          <span class="dim">${im.nw || '?'}×${im.nh || '?'}${filtered ? ` · filtered (${esc(labels[im.id]?.category || '')})` : ''}${(im.nw || 0) < 800 ? ' · small' : ''}</span>
        </button>`;
      })
      .join('') || '<p class="muted">No images on this page.</p>';
}
$('galAll').addEventListener('change', renderGallery);
$('galClose').addEventListener('click', () => $('gallery').close());
$('galNone').addEventListener('click', () => pickImage(null));
$('galGrid').addEventListener('click', (e) => {
  const b = e.target.closest('.gal-item');
  if (b) pickImage(b.dataset.id);
});

async function pickImage(id) {
  const s = job.deck.slides[galleryFor];
  if (!s) return;
  if (id) {
    const im = job.page.images.find((x) => x.id === id);
    // a filtered-out image is restored, fetched and uploaded on demand
    if (!job.restored.includes(id) && job.filter?.labels?.[id]?.keep === false) job.restored.push(id);
    const ok = await ensureImage(im).catch(() => false);
    if (!ok) {
      alert("That image couldn't be downloaded. Try another one.");
      return;
    }
  }
  s.imageId = id;
  if (!id && ['image-left', 'image-right', 'image-full'].includes(s.layout)) s.layout = 'bullets';
  $('gallery').close();
  await saveJobNow();
  renderSlides();
  renderFiltered();
}

// ================================================================ play
let player = null;
let stopFollowing = () => {};
let starting = false;

/** What the popup's "Show last video" and the page modal open: this job on the server. */
async function rememberVideo() {
  const meta = { ...(job.result || {}), title: job.deck.title, apiJobId: job.apiJobId, jobKey, url: job.url, tabId: job.tabId, created: Date.now() };
  // kept in chrome.storage (not IndexedDB) because the player also runs embedded
  // in other sites' pages, where the extension's IndexedDB can be partitioned
  const { videos = {} } = await chrome.storage.local.get('videos');
  videos[jobKey] = meta;
  for (const k of Object.keys(videos).sort().slice(0, -15)) delete videos[k];
  await chrome.storage.local.set({ lastVideo: meta, videos });
}

function closePlayer() {
  stopFollowing();
  player?.pause();
  $('playerOverlay').classList.add('hidden');
  step('edit', 'active');
}

$('play').addEventListener('click', async () => {
  if (starting) return;
  starting = true;
  banner('');
  const label = $('play').textContent;
  $('play').disabled = true;
  $('play').textContent = 'Starting…';
  try {
    await collectImages(); // images picked from the gallery since the draft
    const deck = structuredClone({ ...job.deck, slides: job.deck.slides.filter((s) => s) });
    const voice = job.settings.voice || 'af_heart';
    const speed = job.settings.speed || 1;
    const { runId } = await startNarration(job.apiJobId, { deck, voice, speed });
    await rememberVideo();

    step('edit', 'done');
    step('render', 'active');
    $('plTitle').textContent = deck.title || 'Your video';
    $('plStatus').textContent = 'Preparing narration…';
    $('playerOverlay').classList.remove('hidden');
    // the click on Play lets sound start later, once the first clip arrives
    player ||= new DeckPlayer($('deckPlayer'), { cssHref: chrome.runtime.getURL('shared/slides.css'), img, autoplay: true });
    player.load(deck, deck.slides.map((s) => (s.narration?.trim() ? { pending: true } : { silent: true })), { speed });
    $('deckPlayer').focus();

    stopFollowing();
    stopFollowing = followNarration(
      job.apiJobId,
      (n) => {
        if (n.runId !== runId) return; // a newer Play replaced this one
        player.update(n.slides);
        const voiced = n.slides.filter((s) => !s.silent);
        const ready = voiced.filter((s) => s.url).length;
        $('plStatus').textContent = ready < voiced.length ? `Narrating: ${ready} of ${voiced.length} slides ready` : '';
      },
      {
        onError: (e) => {
          $('plStatus').textContent = userMessage(e, "Some slides couldn't be narrated. Press Play to try again.");
        },
      },
    );
  } catch (e) {
    banner(userMessage(e));
  } finally {
    $('play').textContent = label;
    $('play').disabled = false;
    starting = false;
  }
});

$('plClose').addEventListener('click', closePlayer);
$('plShowPage').addEventListener('click', () => {
  closePlayer();
  chrome.runtime.sendMessage({ type: 'showVideo', tabId: job.tabId, url: job.url, videoKey: jobKey });
});
$('playerOverlay').addEventListener('click', (e) => {
  if (e.target === $('playerOverlay')) closePlayer();
});

// ================================================================ export
let rendering = false;
$('render').addEventListener('click', async () => {
  if (rendering) return;
  rendering = true;
  banner('');
  step('edit', 'done');
  step('render', 'active');
  const ov = $('overlay');
  ov.classList.remove('hidden');
  $('ovTitle').textContent = 'Exporting your video';
  $('ovDone').classList.add('hidden');
  $('ovWorkingActions').classList.remove('hidden');
  $('ovStages').classList.remove('hidden');
  for (const st of document.querySelectorAll('.ov-stage')) {
    st.classList.remove('done');
    st.querySelector('.bar > div').style.width = '0';
  }
  const setStage = (name, frac) => {
    // the render worker reports voice -> slides -> encode -> upload, then render (done)
    const order = ['voice', 'slides', 'encode', 'upload', 'render'];
    const cur = order.indexOf(name);
    for (const st of document.querySelectorAll('.ov-stage')) {
      const idx = order.indexOf(st.dataset.stage);
      const bar = st.querySelector('.bar > div');
      st.classList.toggle('done', idx < cur);
      if (idx < cur) bar.style.width = '100%';
      else if (idx > cur) bar.style.width = '0';
      else if (frac != null) bar.style.width = `${Math.round(frac * 100)}%`;
    }
  };
  try {
    await collectImages(); // images picked from the gallery since the draft
    const deck = { ...job.deck, slides: job.deck.slides.filter((s) => s) };
    busy = 'render';
    const done = await runStep(job.apiJobId, 'render', { deck, voice: job.settings.voice || 'af_heart', speed: job.settings.speed || 1 }, (p) => {
      // until the worker starts, the job's stage is just the step name ("render")
      if (p.stage !== 'render') setStage(p.stage, p.fraction);
      $('ovText').textContent = p.text || '';
    });
    setStage('render');
    const video = done.video;
    if (!video?.url) throw new ApiError('The export finished but the video is missing. Try exporting again.');
    // the video stays on the server; the player asks the API for a fresh link each time
    job.result = { filename: video.filename, duration: video.duration, size: video.size };
    await rememberVideo();
    await saveJobNow();
    step('render', 'done');

    $('ovTitle').textContent = 'Your video is ready';
    $('ovStages').classList.add('hidden');
    $('ovWorkingActions').classList.add('hidden');
    $('ovText').textContent = `${(video.size / 1e6).toFixed(1)} MB · kept for 30 days`;
    $('ovDone').classList.remove('hidden');
    $('ovVideo').src = video.url;
  } catch (e) {
    ov.classList.add('hidden');
    step('render', null);
    step('edit', 'active');
    banner(e.cancelled ? 'Export cancelled.' : userMessage(e));
  } finally {
    busy = null;
    rendering = false;
  }
});

$('ovCancel').addEventListener('click', () => api.cancel(job.apiJobId).catch(() => {}));
$('ovClose').addEventListener('click', () => {
  $('ovVideo').pause();
  $('overlay').classList.add('hidden');
  step('edit', 'active');
});
$('ovShowPage').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'showVideo', tabId: job.tabId, url: job.url, videoKey: jobKey }));
$('ovDownload').addEventListener('click', async () => {
  try {
    // a fresh link: the one the render returned may have expired
    const { video } = await api.getJob(job.apiJobId);
    chrome.downloads.download({ url: video.url, filename: video.filename, saveAs: true });
  } catch (e) {
    banner(userMessage(e));
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('playerOverlay').classList.contains('hidden') && !document.fullscreenElement) closePlayer();
  else if (!$('overlay').classList.contains('hidden') && !rendering) $('ovClose').click();
});

window.addEventListener('beforeunload', (e) => {
  if (rendering || busy) {
    e.preventDefault();
    e.returnValue = '';
  }
});

run();
