import { api, userMessage, ApiError } from './lib/api.js';
import { signIn, signOut, currentUser } from './lib/auth.js';
import { BACKENDS, currentBackend, isConfigured } from './lib/config.js';
import { db, pruneJobs } from './lib/db.js';
import { loadSettings, saveSettings } from './lib/settings.js';
import { consentHTML, giveConsent, hasConsent } from './lib/consent.js';
import { attachVoicePreview } from './lib/voice-preview.js';

const $ = (id) => document.getElementById(id);
let settings = await loadSettings();
let tab = null;
let ready = false; // server reachable and, where needed, signed in
let consented = await hasConsent();

const FALLBACK_VOICES = [
  { id: 'af_heart', label: 'Heart (US, female)' },
  { id: 'bf_emma', label: 'Emma (UK, female)' },
  { id: 'bm_george', label: 'George (UK, male)' },
  { id: 'am_michael', label: 'Michael (US, male)' },
];

// ---------------------------------------------------------------- helpers
function showError(msg) {
  $('error').innerHTML = msg ? `<strong>Can't start.</strong> ${escapeHtml(msg)}` : '';
  $('error').classList.toggle('hidden', !msg);
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
}
function setSeg(el, value) {
  for (const b of el.querySelectorAll('button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(value)));
}
function fillSelect(sel, items, value) {
  // an ElevenLabs voice brings its own sample to preview (lib/voice-preview.js)
  sel.innerHTML = items.map((i) => `<option value="${escapeHtml(i.id)}"${i.previewUrl ? ` data-preview="${escapeHtml(i.previewUrl)}"` : ''}>${escapeHtml(i.label)}</option>`).join('');
  if (items.some((i) => i.id === value)) sel.value = value;
}

// ---------------------------------------------------------------- page info
[tab] = await chrome.tabs.query({ active: true, currentWindow: true });
$('pageTitle').textContent = tab?.title || tab?.url || '';
const restricted = !tab?.url || !/^(https?|file):/.test(tab.url) || /^https:\/\/chromewebstore\.google\.com/.test(tab.url);
if (restricted) showError('Chrome does not let extensions read this kind of page. Open a normal web page and try again.');

// "show last video" is offered once a video has been made
const { lastVideo } = await chrome.storage.local.get('lastVideo');
if (lastVideo?.apiJobId && !restricted) $('last').classList.remove('hidden');

// ---------------------------------------------------------------- settings UI
$('guidance').value = (await chrome.storage.session.get('draftGuidance')).draftGuidance || '';
$('guidance').addEventListener('input', () => chrome.storage.session.set({ draftGuidance: $('guidance').value }));

setSeg($('minutes'), settings.minutes);
$('minutes').addEventListener('click', async (e) => {
  const v = e.target.closest('button')?.dataset.v;
  if (!v) return;
  settings = await saveSettings({ minutes: Number(v) });
  setSeg($('minutes'), v);
});

// lengths past the plan's longest video are greyed out, and a saved one too long moves down
async function applyPlan(plan) {
  const max = plan.maxVideoMinutes;
  for (const b of $('minutes').querySelectorAll('button')) {
    const over = Number(b.dataset.v) > max;
    b.disabled = over;
    b.title = over ? `Up to ${max} minutes on the ${plan.label} plan` : '';
  }
  if (settings.minutes > max) {
    const fits = [...$('minutes').querySelectorAll('button')].map((b) => Number(b.dataset.v)).filter((v) => v <= max);
    settings = await saveSettings({ minutes: Math.max(...fits) });
    setSeg($('minutes'), settings.minutes);
  }
}

fillSelect($('voice'), FALLBACK_VOICES, settings.voice);
$('voice').addEventListener('change', async () => (settings = await saveSettings({ voice: $('voice').value })));
$('speed').value = String(settings.speed);
$('speed').addEventListener('change', async () => (settings = await saveSettings({ speed: Number($('speed').value) })));

fillSelect(
  $('backend'),
  Object.values(BACKENDS).map((b) => ({ id: b.id, label: isConfigured(b) ? b.label : `${b.label} (not set up yet)` })),
  settings.backend,
);
$('backend').addEventListener('change', async () => {
  settings = await saveSettings({ backend: $('backend').value });
  checkServer();
});

// ---------------------------------------------------------------- server and account
function setStatus(kind, text, title) {
  $('statusDot').className = `dot ${kind}`;
  $('statusText').textContent = text;
  $('status').title = title || text;
}

function detail(rows) {
  $('statusDetail').innerHTML = rows
    .map(([k, ok, v]) => `<span class="k"><span class="dot ${ok ? 'ok' : 'warn'}"></span> ${k}</span><span>${escapeHtml(v)}</span>`)
    .join('');
}

function updateButtons() {
  $('go').disabled = restricted || !ready || !consented;
  // nothing leaves the browser until people have read what's sent and agreed
  const asking = ready && !consented;
  $('consent').classList.toggle('hidden', !asking);
  if (asking) $('go').classList.add('hidden');
  else if (ready) $('go').classList.remove('hidden');
}

attachVoicePreview($('voice'), $('voicePreview'));

$('consentText').innerHTML = consentHTML();
$('consentText').querySelector('h2').id = 'consentTitle';
$('agree').addEventListener('click', async () => {
  await giveConsent();
  consented = true;
  updateButtons();
});
$('notNow').addEventListener('click', () => window.close());

async function checkServer() {
  ready = false;
  updateButtons();
  showError('');
  $('signInBox').classList.add('hidden');
  $('account').classList.add('hidden');
  $('go').classList.remove('hidden');
  setStatus('', 'Checking…');
  const backend = await currentBackend();
  const rows = [['Server', false, backend.label]];

  if (!isConfigured(backend)) {
    setStatus('bad', 'Not set up', `${backend.label} has no address in this build yet.`);
    detail(rows);
    showError(`The ${backend.label} server isn't set up in this build yet. Pick another server under Advanced.`);
    return;
  }
  try {
    await api.health();
  } catch (e) {
    setStatus('bad', 'Offline', userMessage(e));
    detail(rows);
    showError(userMessage(e));
    return;
  }
  rows[0][1] = true;

  const user = await currentUser();
  if (!user) {
    setStatus('warn', 'Sign in', 'Sign in to make videos');
    rows.push(['Account', false, 'signed out']);
    detail(rows);
    $('go').classList.add('hidden');
    $('signInBox').classList.remove('hidden');
    return;
  }

  try {
    const [me, voices] = await Promise.all([api.me(), api.voices()]);
    fillSelect($('voice'), voices, settings.voice);
    const used = me.today?.jobs ?? 0;
    const limit = me.limits?.jobsPerDay;
    rows.push(['Account', true, user.local ? 'local test user' : user.email]);
    if (limit) rows.push(['Today', used < limit, `${used} of ${limit} videos`]);
    const left = me.plan ? Math.max(0, Math.floor(me.plan.minutesPerMonth - (me.month?.minutesUsed ?? 0))) : null;
    if (me.plan) rows.push(['Plan', left > 0, `${me.plan.label}: ${left} of ${me.plan.minutesPerMonth} min left this month`]);
    detail(rows);
    if (me.plan) await applyPlan(me.plan);
    if (!user.local) {
      $('accountText').textContent = `${user.email}${me.plan ? ` · ${me.plan.label} plan · ${left} min left` : ''}`;
      $('accountText').title = `Signed in as ${user.email}`;
      $('account').classList.remove('hidden');
    }
    setStatus('ok', 'Ready', `${backend.label}: ready`);
    ready = true;
  } catch (e) {
    // a stale sign-in shows up here as a 401
    if (e.status === 401) {
      await signOut();
      return checkServer();
    }
    setStatus('bad', 'Error', userMessage(e));
    detail(rows);
    showError(userMessage(e));
  }
  updateButtons();
}

$('status').addEventListener('click', () => $('statusDetail').classList.toggle('hidden'));

$('signIn').addEventListener('click', async () => {
  showError('');
  $('signIn').disabled = true;
  try {
    await signIn();
    await checkServer();
  } catch (e) {
    // closing the sign-in window isn't an error worth shouting about
    if (!/did not approve|canceled|cancelled|closed/i.test(e?.message || '')) showError(userMessage(e, "Sign-in didn't complete. Try again."));
  } finally {
    $('signIn').disabled = false;
  }
});

$('signOut').addEventListener('click', async () => {
  await signOut();
  checkServer();
});

checkServer();

// ---------------------------------------------------------------- actions
$('go').addEventListener('click', async () => {
  showError('');
  if (!(await hasConsent())) {
    consented = false;
    updateButtons();
    return;
  }
  $('go').disabled = true;
  $('go').textContent = 'Reading the page…';
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['vendor/Readability.js', 'content/extract.js'],
    });
    const page = results?.[results.length - 1]?.result;
    if (!page?.blocks?.length) throw new ApiError('Found no readable content on this page.');
    const key = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    await db.put('jobs', key, {
      key,
      created: Date.now(),
      tabId: tab.id,
      url: tab.url,
      title: tab.title,
      guidance: $('guidance').value.trim(),
      settings,
      page,
    });
    pruneJobs().catch(() => {});
    await chrome.storage.session.remove('draftGuidance');
    await chrome.tabs.create({ url: chrome.runtime.getURL(`storyboard.html?job=${key}`), index: tab.index + 1 });
    window.close();
  } catch (e) {
    // chrome.scripting errors (a page the browser won't let extensions read) aren't for users
    showError(userMessage(e, "PageCast couldn't read this page. Reload it and try again."));
    $('go').disabled = false;
    $('go').textContent = 'Create storyboard';
  }
});

$('last').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'showVideo', tabId: tab.id, url: tab.url, videoKey: 'last' });
  window.close();
});
