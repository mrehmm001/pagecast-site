// Injected into the page the video was made from: a full-screen modal that hosts
// the extension's player page in an iframe. Shadow DOM keeps the page's CSS out.
(() => {
  const ID = 'pagecast-modal-host';
  document.getElementById(ID)?.remove();

  const key = window.__pagecastVideoKey || 'last';
  const origin = new URL(chrome.runtime.getURL('')).origin;
  const src = chrome.runtime.getURL(`player.html?embed=1&video=${encodeURIComponent(key)}`);

  // a custom tag (not <div>) so generic page selectors never match the host, and
  // !important inline styles so even `* { … !important }` page rules lose
  const host = document.createElement('pagecast-modal');
  host.id = ID;
  for (const [k, v] of Object.entries({
    all: 'initial', position: 'fixed', inset: '0', 'z-index': '2147483647', display: 'block',
    border: '0', margin: '0', padding: '0', background: 'none', transform: 'none', filter: 'none', opacity: '1',
  })) host.style.setProperty(k, v, 'important');
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      .backdrop { position: fixed; inset: 0; background: rgba(12, 13, 16, .72); backdrop-filter: blur(3px);
        display: flex; align-items: center; justify-content: center; padding: 24px; box-sizing: border-box;
        animation: fade .18s ease-out; font: 14px/1.4 system-ui, sans-serif; }
      .frame { width: min(1280px, 100%, calc((100vh - 48px - 64px) * 16 / 9)); aspect-ratio: 16 / 10.4; max-height: calc(100vh - 48px);
        border: 0; border-radius: 14px; background: #121419; box-shadow: 0 30px 80px -20px rgba(0,0,0,.6); display: block; }
      .fallback { display: none; flex-direction: column; align-items: center; gap: 14px; color: #f3f1ec; text-align: center; max-width: 420px; }
      .fallback button { font: 600 14px system-ui, sans-serif; padding: 10px 18px; border-radius: 8px; border: 0; background: #ef7b4a; color: #1a0d06; cursor: pointer; }
      .fallback .x { background: transparent; color: #f3f1ec; border: 1px solid rgba(255,255,255,.35); }
      @keyframes fade { from { opacity: 0 } to { opacity: 1 } }
    </style>
    <div class="backdrop" part="backdrop">
      <iframe class="frame" title="PageCast video" allow="autoplay; fullscreen; clipboard-write" src="${src}"></iframe>
      <div class="fallback" role="dialog" aria-label="PageCast video">
        <div>This site blocks the in-page player.</div>
        <button type="button" class="open">Open the video in a window</button>
        <button type="button" class="x">Close</button>
      </div>
    </div>`;

  const backdrop = root.querySelector('.backdrop');
  const frame = root.querySelector('iframe');
  const fallback = root.querySelector('.fallback');
  const prevOverflow = document.documentElement.style.overflow;
  document.documentElement.style.overflow = 'hidden';

  let ready = false;
  function close() {
    window.removeEventListener('message', onMessage);
    document.removeEventListener('keydown', onKey, true);
    document.documentElement.style.overflow = prevOverflow;
    host.remove();
  }
  function onMessage(e) {
    if (e.origin !== origin) return;
    if (e.data === 'pagecast:ready') ready = true;
    if (e.data === 'pagecast:close') close();
  }
  function onKey(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      close();
    }
  }
  window.addEventListener('message', onMessage);
  document.addEventListener('keydown', onKey, true);
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });
  root.querySelector('.open').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'openPlayerWindow', videoKey: key });
    close();
  });
  root.querySelector('.x').addEventListener('click', close);

  // some sites' security policy blocks extension iframes: offer a window instead
  setTimeout(() => {
    if (ready) return;
    frame.style.display = 'none';
    fallback.style.display = 'flex';
  }, 2500);

  (document.body || document.documentElement).appendChild(host);
  frame.focus();
})();
