// Page extractor. Injected with chrome.scripting.executeScript (after
// vendor/Readability.js) and returns its result as the script's completion value.
//
// It COLLECTS EVERYTHING AND DECIDES NOTHING: there are no ad or boilerplate rules
// here. The only things skipped are ones that can never be content (scripts,
// styles, unrendered elements, tracking pixels, icon-sized images). Every block
// and image carries layout hints so the AI filter can judge it.
(() => {
  const started = performance.now();
  const MAX_BLOCKS = 4000;
  const MAX_IMAGES = 400;
  const MAX_BLOCK_TEXT = 6000;

  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'LINK', 'META', 'HEAD', 'OBJECT', 'EMBED', 'MAP', 'AREA', 'BR', 'HR', 'WBR', 'INPUT', 'SELECT', 'OPTION', 'TEXTAREA']);
  const HEADINGS = { H1: 1, H2: 2, H3: 3, H4: 4, H5: 5, H6: 6 };
  const LANDMARK_TAGS = { MAIN: 'main', ARTICLE: 'article', NAV: 'nav', ASIDE: 'aside', HEADER: 'header', FOOTER: 'footer', DIALOG: 'dialog', FORM: 'form' };
  const LANDMARK_ROLES = { main: 'main', article: 'article', navigation: 'nav', complementary: 'aside', banner: 'header', contentinfo: 'footer', dialog: 'dialog', alertdialog: 'dialog', search: 'search', form: 'form', region: null };

  const here = location.hostname.replace(/^www\./, '');
  const blocks = [];
  const images = [];
  const seenText = new Set();
  const seenImg = new Set();
  let lastHeading = '';
  let lastBlockId = null;

  // ------------------------------------------------------------ helpers
  const clean = (s) => String(s || '').replace(/[ \s]+/g, ' ').trim();
  const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

  function visible(el) {
    const cs = getComputedStyle(el);
    // display:contents wrappers have no box, so checkVisibility() says false, but
    // their children render normally (React/styled-components sites use them a lot)
    if (cs.display === 'contents') return true;
    if (el.checkVisibility) return el.checkVisibility({ checkVisibilityCSS: true });
    return cs.display !== 'none' && cs.visibility !== 'hidden';
  }

  function domainOf(url) {
    try {
      return new URL(url, location.href).hostname.replace(/^www\./, '');
    } catch {
      return '';
    }
  }
  const offsite = (d) => d && d !== here && !d.endsWith('.' + here) && !here.endsWith('.' + d);

  const ctxCache = new WeakMap();
  // landmark, fixed/sticky and iframe-slot flags inherited from ancestors
  function context(el) {
    if (!el || el === document.body || el === document.documentElement) return { lm: '', fixed: false };
    if (ctxCache.has(el)) return ctxCache.get(el);
    const parent = context(el.parentElement);
    let lm = parent.lm;
    const role = el.getAttribute?.('role');
    const own = LANDMARK_TAGS[el.tagName] || (role && LANDMARK_ROLES[role]);
    // the innermost landmark wins, except header/footer inside article stay article-ish
    if (own) lm = own;
    let fixed = parent.fixed;
    if (!fixed) {
      const pos = getComputedStyle(el).position;
      fixed = pos === 'fixed' || pos === 'sticky';
    }
    const r = { lm, fixed };
    ctxCache.set(el, r);
    return r;
  }

  function trail(el) {
    const parts = [];
    let cur = el;
    for (let depth = 0; cur && cur !== document.body && depth < 8 && parts.length < 3; depth++, cur = cur.parentElement) {
      const cls = [...(cur.classList || [])].slice(0, 2).map((c) => clip(c, 28));
      const id = cur.id ? '#' + clip(cur.id, 28) : '';
      if (cls.length || id) parts.unshift(cur.tagName.toLowerCase() + id + (cls.length ? '.' + cls.join('.') : ''));
    }
    return parts.join('>');
  }

  function linkStats(el, textLen) {
    let linkText = 0;
    const domains = new Set();
    let off = false;
    for (const a of el.querySelectorAll ? el.querySelectorAll('a[href]') : []) {
      linkText += clean(a.textContent).length;
      const d = domainOf(a.getAttribute('href'));
      if (d) {
        domains.add(d);
        if (offsite(d)) off = true;
      }
    }
    if (el.tagName === 'A' && el.href) {
      linkText = textLen;
      const d = domainOf(el.href);
      if (d) domains.add(d);
      if (offsite(d)) off = true;
    }
    return {
      ld: textLen ? Math.round(Math.min(1, linkText / textLen) * 100) / 100 : 0,
      off,
      domains: [...domains].filter(offsite).slice(0, 4),
    };
  }

  function hints(el, textLen = 0) {
    const ctx = context(el);
    const r = el.getBoundingClientRect();
    const h = {
      lm: ctx.lm || undefined,
      trail: trail(el) || undefined,
      y: Math.round(r.top + scrollY),
    };
    if (ctx.fixed) h.fixed = true;
    if (textLen || el.querySelector?.('a[href]')) Object.assign(h, linkStats(el, textLen));
    if (!h.domains?.length) delete h.domains;
    if (!h.off) delete h.off;
    if (!h.ld) delete h.ld;
    return h;
  }

  function addBlock(type, el, data) {
    if (blocks.length >= MAX_BLOCKS) return;
    const text = data.text != null ? clip(clean(data.text), MAX_BLOCK_TEXT) : '';
    const key = type + '|' + (text || JSON.stringify(data.items || data.rows || ''));
    if (key.length < 6) return;
    if (seenText.has(key)) return; // repeated identical block (e.g. duplicated mobile/desktop menus)
    seenText.add(key);
    const id = 'b' + (blocks.length + 1);
    const allText = text || (data.items || []).join(' ') || (data.rows || []).flat().join(' ');
    const b = { id, type, ...data, text: text || undefined, hints: hints(el, allText.length) };
    if (!b.text) delete b.text;
    blocks.push(b);
    lastBlockId = id;
    if (type === 'heading') lastHeading = text;
  }

  // ------------------------------------------------------------ images
  function bestSrc(img) {
    const lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original') || img.getAttribute('data-url');
    let src = img.currentSrc || img.src;
    // lazy-loading placeholders: tiny data URIs or 1px gifs while the real URL waits in data-src
    if (lazy && (!src || src.startsWith('data:') || img.naturalWidth < 20)) src = lazy;
    const srcset = img.getAttribute('data-srcset') || (src?.startsWith('data:') ? img.getAttribute('srcset') : null);
    if (srcset && (!src || src.startsWith('data:'))) {
      const cands = srcset.split(',').map((s) => s.trim().split(/\s+/)).filter((p) => p[0]);
      cands.sort((a, b) => (parseFloat(b[1]) || 0) - (parseFloat(a[1]) || 0));
      if (cands[0]) src = cands[0][0];
    }
    try {
      return src ? new URL(src, location.href).href : null;
    } catch {
      return null;
    }
  }

  function addImage(el, { src, kind = 'img', nw, nh, alt = '', caption = '' }) {
    if (!src || images.length >= MAX_IMAGES) return;
    if (src.startsWith('data:') && src.length < 2000 && kind !== 'svg') return; // placeholder or pixel
    const r = el.getBoundingClientRect();
    const rw = Math.round(r.width);
    const rh = Math.round(r.height);
    nw = nw || rw;
    nh = nh || rh;
    // tracking pixels and icon-sized images can never work on a 1920x1080 slide
    if ((nw <= 2 && nh <= 2) || (Math.max(nw, rw) < 48 && Math.max(nh, rh) < 48)) return;
    const key = src.split('#')[0];
    if (seenImg.has(key)) return;
    seenImg.add(key);
    const link = el.closest?.('a[href]');
    const im = {
      id: 'i' + (images.length + 1),
      kind,
      src,
      nw, nh, rw, rh,
      alt: clip(clean(alt), 300) || undefined,
      caption: clip(clean(caption), 400) || undefined,
      near: lastHeading ? clip(lastHeading, 120) : undefined,
      after: lastBlockId || undefined,
      link: link ? domainOf(link.href) : undefined,
      hints: hints(el),
    };
    for (const k of Object.keys(im)) if (im[k] === undefined) delete im[k];
    images.push(im);
  }

  function captionFor(el) {
    const fig = el.closest('figure');
    const cap = fig?.querySelector('figcaption');
    return cap ? cap.textContent : el.getAttribute('title') || '';
  }

  // Pages show thumbnails; slides are 1920x1080. Ask for a bigger version where the
  // page says one exists: the largest srcset candidate, or a wider Wikimedia thumb.
  function upgrade(img, src) {
    let nw = img.naturalWidth;
    let nh = img.naturalHeight;
    const ratio = nw && nh ? nh / nw : 0;
    const cands = (img.getAttribute('srcset') || '')
      .split(',')
      .map((s) => s.trim().split(/\s+/))
      .filter((p) => p[0] && !p[0].startsWith('data:'))
      .map(([u, d]) => ({ u, w: /w$/.test(d || '') ? parseFloat(d) : /x$/.test(d || '') ? parseFloat(d) * (nw || 0) : 0 }))
      .sort((a, b) => b.w - a.w);
    if (cands[0] && cands[0].w > nw) {
      try {
        src = new URL(cands[0].u, location.href).href;
        nw = Math.round(cands[0].w);
        nh = ratio ? Math.round(nw * ratio) : nh;
      } catch {}
    }
    const fileW = Number(img.getAttribute('data-file-width'));
    const m = /^(https:\/\/[a-z]+\.wikimedia\.org\/.+\/thumb\/.+\/)(\d+)px-([^/?#]+)(\?.*)?$/.exec(src);
    if (m && fileW) {
      // Wikimedia only serves standard thumbnail widths (1600 is refused, 1280/1920 work)
      const target = [1920, 1280, 960].find((w) => w <= fileW);
      if (target && target > Number(m[2])) {
        src = `${m[1]}${target}px-${m[3]}`;
        nw = target;
        nh = ratio ? Math.round(target * ratio) : Number(img.getAttribute('data-file-height')) || nh;
      }
    }
    return { src, nw, nh };
  }

  function handleImg(img) {
    const up = upgrade(img, bestSrc(img) || '');
    addImage(img, {
      src: up.src || null,
      nw: up.nw,
      nh: up.nh,
      alt: img.getAttribute('alt') || img.getAttribute('aria-label') || '',
      caption: captionFor(img),
    });
  }

  function handleSvg(svg) {
    const r = svg.getBoundingClientRect();
    if (r.width < 200 || r.height < 150) return; // icons and logos
    try {
      const clone = svg.cloneNode(true);
      clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
      if (!clone.getAttribute('width')) clone.setAttribute('width', Math.round(r.width));
      if (!clone.getAttribute('height')) clone.setAttribute('height', Math.round(r.height));
      const xml = new XMLSerializer().serializeToString(clone);
      if (xml.length > 600000) return;
      addImage(svg, {
        kind: 'svg',
        src: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml),
        nw: Math.round(r.width),
        nh: Math.round(r.height),
        alt: svg.getAttribute('aria-label') || svg.querySelector('title')?.textContent || '',
        caption: captionFor(svg),
      });
    } catch {}
  }

  function handleBackground(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 300 || r.height < 200) return;
    const bg = getComputedStyle(el).backgroundImage;
    const m = bg && bg !== 'none' && /url\(["']?(.*?)["']?\)/.exec(bg);
    if (!m) return;
    addImage(el, { kind: 'bg', src: new URL(m[1], location.href).href, alt: el.getAttribute('aria-label') || '' });
  }

  // ------------------------------------------------------------ blocks
  // display:contents is deliberately absent: such wrappers are walked into as
  // containers, otherwise a whole React page collapses into one "inline" run
  const INLINE_DISPLAY = /^(inline|inline-block|inline-flex|inline-grid|ruby)$/;

  // Elements that always start their own block, whatever their CSS display says
  // (Wikipedia, for one, lays headings out as inline items inside flex rows).
  const BLOCK_TAGS = new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'P', 'UL', 'OL', 'DL', 'TABLE', 'PRE', 'BLOCKQUOTE', 'FIGURE', 'SECTION', 'ARTICLE', 'ASIDE', 'NAV', 'HEADER', 'FOOTER', 'MAIN', 'FORM', 'IFRAME', 'VIDEO', 'LI', 'DETAILS']);
  const MEDIA_TAGS = new Set(['IMG', 'PICTURE', 'svg', 'SVG']);

  function isInline(node) {
    if (node.nodeType === Node.TEXT_NODE) return true;
    if (node.nodeType !== Node.ELEMENT_NODE) return false;
    if (BLOCK_TAGS.has(node.tagName) || MEDIA_TAGS.has(node.tagName)) return false;
    return INLINE_DISPLAY.test(getComputedStyle(node).display);
  }

  function listItems(list) {
    return [...list.children]
      .filter((li) => li.tagName === 'LI' && visible(li))
      .map((li) => clip(clean(li.innerText || li.textContent), 400))
      .filter(Boolean)
      .slice(0, 60);
  }

  function tableRows(table) {
    const rows = [];
    for (const tr of table.querySelectorAll('tr')) {
      if (rows.length >= 40) break;
      const cells = [...tr.children].filter((c) => /^(TD|TH)$/.test(c.tagName)).slice(0, 12).map((c) => clip(clean(c.innerText || c.textContent), 200));
      if (cells.some(Boolean)) rows.push(cells);
    }
    return rows;
  }

  // Tables used for page layout hold blocks, not data: walk into them instead.
  function isLayoutTable(t) {
    return !!t.querySelector('table, p, h1, h2, h3, div div div') || clean(t.textContent).length > 5000;
  }

  function flushRun(run, parent) {
    if (!run.length) return;
    // nodes carry their own spacing; joining with '' avoids "( pl. :" artefacts
    const text = clean(run.map((n) => (n.nodeType === Node.TEXT_NODE ? n.textContent : n.innerText || n.textContent)).join(''));
    if (text.length < 2) return;
    // a short run that is only a link or button reads as a call to action
    const onlyAction =
      run.filter((n) => n.nodeType === Node.ELEMENT_NODE).length === 1 &&
      run.every((n) => n.nodeType !== Node.TEXT_NODE || !clean(n.textContent)) &&
      /^(A|BUTTON)$/.test(run.find((n) => n.nodeType === Node.ELEMENT_NODE).tagName) &&
      text.length < 60;
    addBlock(onlyAction ? 'cta' : 'paragraph', parent, { text });
    // images nested inside inline elements (e.g. <a><img></a>)
    for (const n of run) if (n.nodeType === Node.ELEMENT_NODE) n.querySelectorAll('img').forEach((img) => visible(img) && handleImg(img));
  }

  function walk(el, inIframeSlot = false) {
    if (blocks.length >= MAX_BLOCKS) return;
    const tag = el.tagName;
    if (SKIP.has(tag)) return;
    if (!visible(el)) return;

    if (tag in HEADINGS) {
      addBlock('heading', el, { level: HEADINGS[tag], text: el.innerText || el.textContent });
      el.querySelectorAll('img').forEach(handleImg);
      return;
    }
    if (tag === 'IMG') return handleImg(el);
    if (tag === 'PICTURE') {
      const img = el.querySelector('img');
      if (img) handleImg(img);
      return;
    }
    if (tag === 'svg' || tag === 'SVG') return handleSvg(el);
    if (tag === 'VIDEO') {
      if (el.poster) addImage(el, { kind: 'poster', src: new URL(el.poster, location.href).href, alt: el.getAttribute('aria-label') || el.title || '', caption: captionFor(el) });
      return;
    }
    if (tag === 'IFRAME') {
      const src = el.getAttribute('src') || '';
      const r = el.getBoundingClientRect();
      if (r.width < 20 || r.height < 20) return;
      const before = blocks.length;
      addBlock('embed', el, { text: `[embedded frame from ${domainOf(src) || 'unknown'}${el.title ? ': ' + el.title : ''}]`, src: clip(src, 200) });
      if (blocks.length > before) {
        const h = blocks[blocks.length - 1].hints;
        h.iframe = true;
        const d = domainOf(src);
        if (offsite(d)) h.domains = [d];
      }
      return;
    }
    if (tag === 'UL' || tag === 'OL' || tag === 'DL') {
      const items = tag === 'DL' ? [...el.querySelectorAll('dt,dd')].map((x) => clip(clean(x.innerText), 400)).filter(Boolean).slice(0, 60) : listItems(el);
      if (items.length) {
        const before = blocks.length;
        addBlock('list', el, { items });
        const last = blocks[blocks.length - 1];
        if (blocks.length > before && last.hints.ld > 0.9) last.type = 'link-group';
      }
      el.querySelectorAll('img, picture, svg, video').forEach((m) => {
        if (!visible(m)) return;
        if (m.tagName === 'IMG') handleImg(m);
        else if (m.tagName === 'VIDEO' && m.poster) addImage(m, { kind: 'poster', src: new URL(m.poster, location.href).href });
        else if (m.tagName.toLowerCase() === 'svg') handleSvg(m);
      });
      return;
    }
    if (tag === 'TABLE' && !isLayoutTable(el)) {
      const rows = tableRows(el);
      if (rows.length) addBlock('table', el, { rows, caption: clean(el.querySelector('caption')?.textContent) || undefined });
      el.querySelectorAll('img').forEach(handleImg);
      return;
    }
    if (tag === 'PRE') {
      // code keeps its whitespace, so it bypasses addBlock's text clean-up
      const code = (el.innerText || el.textContent || '').replace(/\s+$/, '');
      const key = 'code|' + code;
      if (code.trim() && !seenText.has(key) && blocks.length < MAX_BLOCKS) {
        seenText.add(key);
        const id = 'b' + (blocks.length + 1);
        blocks.push({ id, type: 'code', text: clip(code, MAX_BLOCK_TEXT), hints: hints(el, code.length) });
        lastBlockId = id;
      }
      return;
    }
    if (tag === 'BLOCKQUOTE') {
      addBlock('quote', el, { text: el.innerText || el.textContent, cite: clean(el.querySelector('cite, footer')?.textContent) || undefined });
      el.querySelectorAll('img').forEach(handleImg);
      return;
    }
    if (tag === 'FIGURE') {
      const cap = el.querySelector('figcaption');
      // walk the figure's media, the caption travels with each image
      [...el.children].forEach((c) => c !== cap && walk(c, inIframeSlot));
      return;
    }

    handleBackground(el);

    // generic container: group inline runs into paragraphs, recurse into blocks
    let run = [];
    for (const child of el.childNodes) {
      if (child.nodeType === Node.ELEMENT_NODE && SKIP.has(child.tagName)) continue; // <style>/<link> inside text must not split it
      if (child.nodeType === Node.ELEMENT_NODE && MEDIA_TAGS.has(child.tagName)) {
        // images sitting in running text (formulas, inline figures) don't break the paragraph
        if (visible(child)) walk(child, inIframeSlot);
        continue;
      }
      if (child.nodeType === Node.ELEMENT_NODE && !visible(child)) continue; // hidden bits must not split a paragraph either
      if (isInline(child)) {
        run.push(child);
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        flushRun(run, el);
        run = [];
        walk(child, inIframeSlot);
      }
    }
    flushRun(run, el);

    // open shadow roots (web components) hold real content on some sites
    if (el.shadowRoot) for (const c of el.shadowRoot.children) walk(c, inIframeSlot);
  }

  // ------------------------------------------------------------ meta
  function metaContent(sel) {
    return clean(document.querySelector(sel)?.getAttribute('content') || '');
  }

  function brandColors() {
    const out = [];
    const tc = metaContent('meta[name="theme-color"]');
    if (tc) out.push(tc);
    const toHex = (c) => {
      const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(c || '');
      if (!m || (m[4] !== undefined && +m[4] < 0.5)) return null;
      const [r, g, b] = [m[1], m[2], m[3]].map(Number);
      const sat = Math.max(r, g, b) - Math.min(r, g, b);
      if (sat < 30) return null; // greys, black, white say nothing about the brand
      return '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
    };
    for (const sel of ['header', '[role=banner]', 'nav', '.header', '#header']) {
      const el = document.querySelector(sel);
      if (!el) continue;
      const c = toHex(getComputedStyle(el).backgroundColor);
      if (c) out.push(c);
    }
    const link = document.querySelector('main a[href], article a[href], a[href]');
    const lc = link && toHex(getComputedStyle(link).color);
    if (lc) out.push(lc);
    return [...new Set(out.map((c) => c.toLowerCase()))].slice(0, 4);
  }

  // Readability's main-content guess, used only as a hint ("rd") on items it includes.
  function readabilityHint() {
    try {
      if (typeof Readability !== 'function') return null;
      const art = new Readability(document.cloneNode(true), { charThreshold: 300 }).parse();
      if (!art) return null;
      const text = clean(art.textContent);
      const imgs = new Set();
      const tmp = document.createElement('div');
      tmp.innerHTML = art.content || '';
      tmp.querySelectorAll('img').forEach((i) => {
        const s = i.getAttribute('src');
        if (s) try { imgs.add(new URL(s, location.href).href.split('#')[0]); } catch {}
      });
      return { text, imgs, title: art.title, byline: art.byline, siteName: art.siteName, excerpt: art.excerpt };
    } catch {
      return null;
    }
  }

  // ------------------------------------------------------------ run
  const og = metaContent('meta[property="og:image"]') || metaContent('meta[name="twitter:image"]');
  walk(document.body);
  if (og) {
    lastBlockId = null;
    const ogUrl = (() => { try { return new URL(og, location.href).href; } catch { return null; } })();
    if (ogUrl && !seenImg.has(ogUrl)) {
      seenImg.add(ogUrl);
      images.push({ id: 'i' + (images.length + 1), kind: 'og', src: ogUrl, alt: metaContent('meta[property="og:image:alt"]') || undefined, hints: { lm: 'meta' } });
    }
  }

  const rd = readabilityHint();
  if (rd) {
    for (const b of blocks) {
      const probe = clean(b.text || (b.items || [])[0] || (b.rows || [])[0]?.join(' ') || '').slice(0, 60);
      if (probe.length >= 12 && rd.text.includes(probe)) b.hints.rd = true;
    }
    for (const im of images) if (rd.imgs.has(im.src.split('#')[0])) im.hints.rd = true;
  }

  const meta = {
    title: clean(document.title) || rd?.title || '',
    url: location.href,
    siteName: metaContent('meta[property="og:site_name"]') || rd?.siteName || here,
    byline: rd?.byline || metaContent('meta[name="author"]') || undefined,
    description: metaContent('meta[name="description"]') || metaContent('meta[property="og:description"]') || rd?.excerpt || undefined,
    lang: document.documentElement.lang || undefined,
    brandColors: brandColors(),
    readabilityTitle: rd?.title || undefined,
  };

  return {
    meta,
    blocks,
    images,
    stats: {
      blocks: blocks.length,
      images: images.length,
      chars: blocks.reduce((n, b) => n + (b.text?.length || 0) + (b.items || []).join('').length, 0),
      ms: Math.round(performance.now() - started),
      truncated: blocks.length >= MAX_BLOCKS,
    },
  };
})();
