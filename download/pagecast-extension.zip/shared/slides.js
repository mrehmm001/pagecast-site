// Slide templates: the single source of truth for how a slide looks. Used by the
// storyboard preview (extension page) and by the host renderer (headless Chrome),
// so what you edit is exactly what ends up in the video. No DOM needed to build
// the HTML; fitSlide() runs inside the rendered document to shrink overflowing text.

export const W = 1920;
export const H = 1080;

export const LAYOUTS = {
  title:        { label: 'Title',            fields: ['heading', 'subheading', 'imageId'] },
  bullets:      { label: 'Bullets',          fields: ['heading', 'bullets'] },
  'image-left': { label: 'Image left',       fields: ['heading', 'bullets', 'body', 'imageId', 'caption', 'imageFit'] },
  'image-right':{ label: 'Image right',      fields: ['heading', 'bullets', 'body', 'imageId', 'caption', 'imageFit'] },
  'image-full': { label: 'Full-bleed image', fields: ['heading', 'subheading', 'imageId', 'caption'] },
  quote:        { label: 'Quote',            fields: ['quote', 'attribution', 'imageId'] },
  stat:         { label: 'Big number',       fields: ['stat', 'statLabel', 'heading', 'body'] },
  'two-col':    { label: 'Two columns',      fields: ['heading', 'columns'] },
  table:        { label: 'Table',            fields: ['heading', 'table'] },
  code:         { label: 'Code',             fields: ['heading', 'code', 'codeLang'] },
  closing:      { label: 'Closing',          fields: ['heading', 'subheading', 'bullets'] },
};

export const LAYOUT_NAMES = Object.keys(LAYOUTS);

// ---------------------------------------------------------------- helpers
export function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// escape, then allow **bold** as the only markup
function rich(s) {
  return esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
}

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex || '').trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
}
const toHex = (rgb) => '#' + rgb.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
function lum(rgb) {
  const [r, g, b] = rgb.map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

// Derive accent variants that stay readable on both the light and dark slides.
export function accentVars(accent) {
  let rgb = hexToRgb(accent) || [217, 83, 30];
  // near-grey brand colours make a dull deck; fall back to a warm default
  const sat = Math.max(...rgb) - Math.min(...rgb);
  if (sat < 24) rgb = [217, 83, 30];
  let onLight = rgb;
  while (lum(onLight) > 0.22) onLight = mix(onLight, [0, 0, 0], 0.12);
  let onDark = rgb;
  while (lum(onDark) < 0.28) onDark = mix(onDark, [255, 255, 255], 0.12);
  return {
    '--accent': toHex(onLight),
    '--accent-dark-bg': toHex(onDark),
    '--accent-wash': toHex(mix(rgb, [246, 244, 239], 0.86)),
  };
}

function imgTag(src, fit = 'cover', extra = '') {
  if (!src) return `<div class="img-missing"></div>`;
  return `<img class="img fit-${fit === 'contain' ? 'contain' : 'cover'}" src="${esc(src)}" ${extra} alt="">`;
}

function bulletList(items, cls = '') {
  const list = (items || []).filter((b) => String(b || '').trim());
  if (!list.length) return '';
  return `<ul class="bullets ${cls}">${list.map((b) => `<li>${rich(b)}</li>`).join('')}</ul>`;
}

function chrome(deck, index, total, dark) {
  const site = esc(deck.siteName || '');
  const num = total ? `${String(index + 1).padStart(2, '0')} <span>/ ${String(total).padStart(2, '0')}</span>` : '';
  return `<div class="chrome ${dark ? 'on-dark' : ''}"><div class="site">${site}</div><div class="num">${num}</div></div>`;
}

// ---------------------------------------------------------------- layouts
const render = {
  title(s, d, img) {
    const src = img(s.imageId);
    return `
      <div class="title-wrap ${src ? 'has-img' : ''}">
        <div class="title-text">
          ${d.siteName ? `<div class="kicker">${esc(d.siteName)}</div>` : ''}
          <h1 class="fit">${rich(s.heading || d.title)}</h1>
          ${s.subheading ? `<p class="sub">${rich(s.subheading)}</p>` : ''}
          <div class="rule"></div>
        </div>
        ${src ? `<div class="title-img">${imgTag(src, 'cover')}</div>` : ''}
      </div>`;
  },

  bullets(s) {
    return `
      <h2>${rich(s.heading)}</h2>
      <div class="body fit">${bulletList(s.bullets)}${s.body ? `<p class="para">${rich(s.body)}</p>` : ''}</div>`;
  },

  'image-left'(s, d, img) { return split(s, img, 'left'); },
  'image-right'(s, d, img) { return split(s, img, 'right'); },

  'image-full'(s, d, img) {
    const src = img(s.imageId);
    return `
      <div class="full-img">${imgTag(src, 'cover')}</div>
      <div class="full-shade"></div>
      <div class="full-text">
        ${s.heading ? `<h2>${rich(s.heading)}</h2>` : ''}
        ${s.subheading ? `<p class="sub">${rich(s.subheading)}</p>` : ''}
        ${s.caption ? `<p class="cap">${esc(s.caption)}</p>` : ''}
      </div>`;
  },

  quote(s, d, img) {
    const src = img(s.imageId);
    return `
      <div class="quote-wrap ${src ? 'has-img' : ''}">
        ${src ? `<div class="quote-img">${imgTag(src, 'cover')}</div>` : ''}
        <div class="quote-text fit">
          <div class="qmark">“</div>
          <blockquote>${rich(s.quote)}</blockquote>
          ${s.attribution ? `<div class="attr">— ${esc(s.attribution)}</div>` : ''}
        </div>
      </div>`;
  },

  stat(s) {
    return `
      <div class="stat-wrap">
        <div class="stat-num">${esc(s.stat)}</div>
        <div class="stat-side fit">
          ${s.statLabel ? `<div class="stat-label">${rich(s.statLabel)}</div>` : ''}
          ${s.heading ? `<h2>${rich(s.heading)}</h2>` : ''}
          ${s.body ? `<p class="para">${rich(s.body)}</p>` : ''}
        </div>
      </div>`;
  },

  'two-col'(s) {
    const cols = (s.columns || []).slice(0, 2);
    while (cols.length < 2) cols.push({ heading: '', bullets: [] });
    return `
      <h2>${rich(s.heading)}</h2>
      <div class="cols">
        ${cols.map((c) => `<div class="col fit"><h3>${rich(c.heading)}</h3>${bulletList(c.bullets, 'small')}</div>`).join('')}
      </div>`;
  },

  table(s) {
    const t = s.table || {};
    const headers = t.headers || [];
    const rows = (t.rows || []).slice(0, 10);
    return `
      <h2>${rich(s.heading)}</h2>
      <div class="body fit">
        <table class="tbl">
          ${headers.length ? `<thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>` : ''}
          <tbody>${rows.map((r) => `<tr>${(r || []).map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody>
        </table>
      </div>`;
  },

  code(s) {
    return `
      <h2>${rich(s.heading)}</h2>
      <div class="body fit">
        <pre class="codeblock"><code>${esc(s.code)}</code></pre>
        ${s.codeLang ? `<div class="lang">${esc(s.codeLang)}</div>` : ''}
      </div>`;
  },

  closing(s, d) {
    return `
      <div class="closing-wrap fit">
        <h1>${rich(s.heading || 'Thanks for watching')}</h1>
        ${s.subheading ? `<p class="sub">${rich(s.subheading)}</p>` : ''}
        ${bulletList(s.bullets, 'on-dark')}
        ${d.url ? `<div class="source">Source: ${esc(shortUrl(d.url))}</div>` : ''}
      </div>`;
  },
};

function split(s, img, side) {
  const src = img(s.imageId);
  const text = `
    <div class="split-text">
      <h2>${rich(s.heading)}</h2>
      <div class="body fit">${bulletList(s.bullets, 'small')}${s.body ? `<p class="para">${rich(s.body)}</p>` : ''}</div>
    </div>`;
  const pic = `
    <figure class="split-img ${s.imageFit === 'contain' ? 'contain' : ''}">
      ${imgTag(src, s.imageFit)}
      ${s.caption ? `<figcaption>${esc(s.caption)}</figcaption>` : ''}
    </figure>`;
  return `<div class="split ${side}">${side === 'left' ? pic + text : text + pic}</div>`;
}

function shortUrl(u) {
  try {
    const x = new URL(u);
    return (x.hostname.replace(/^www\./, '') + x.pathname).replace(/\/$/, '');
  } catch {
    return u;
  }
}

const DARK = new Set(['title', 'closing', 'image-full']);

/**
 * HTML for one slide (the element only, no <html> wrapper).
 * @param {object} slide
 * @param {{title?:string, accent?:string, siteName?:string, url?:string}} deck
 * @param {{img:(id:string)=>string|null, index?:number, total?:number}} opts
 */
export function slideHTML(slide, deck, { img = () => null, index = 0, total = 0 } = {}) {
  const layout = LAYOUTS[slide.layout] ? slide.layout : 'bullets';
  const vars = Object.entries(accentVars(deck.accent)).map(([k, v]) => `${k}:${v}`).join(';');
  const dark = DARK.has(layout);
  const inner = render[layout](slide, deck, img);
  const showChrome = layout !== 'title';
  return `<div class="slide layout-${layout} ${dark ? 'dark' : 'light'}" style="${vars}">${inner}${
    showChrome ? chrome(deck, index, total, dark) : ''
  }</div>`;
}

// A full standalone document, used by the host renderer.
export function slideDocument(slide, deck, { img, index, total, cssHref }) {
  return `<!doctype html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="${esc(cssHref)}">
<style>html,body{margin:0;padding:0;width:${W}px;height:${H}px;overflow:hidden;background:#000}</style>
</head><body>${slideHTML(slide, deck, { img, index, total })}</body></html>`;
}

// Shrink text in every .fit region until it no longer overflows. Runs in the page
// (host: via puppeteer page.evaluate; preview: against the iframe document).
export function fitSlide(doc) {
  const regions = doc.querySelectorAll('.fit');
  for (const el of regions) {
    let k = 1;
    el.style.setProperty('--k', k);
    let guard = 0;
    while (guard++ < 20 && (el.scrollHeight > el.clientHeight + 2 || el.scrollWidth > el.clientWidth + 2) && k > 0.5) {
      k = Math.round((k - 0.05) * 100) / 100;
      el.style.setProperty('--k', k);
    }
  }
}
