// Slide timing, shared by the player in the extension and the MP4 export
// (backend/src/render/video.ts uses the same numbers; a backend test checks that
// both agree). A slide shows LEAD seconds of silence, its narration, then TAIL;
// the next slide fades in over the last XFADE seconds of that silence, so no
// speech is ever covered by a transition.

export const LEAD = 0.6;
export const TAIL = 0.8;
export const XFADE = 0.5;
export const MIN_SLIDE = 3;
/** spoken words per second at 1× (150 a minute), for slides whose clip isn't ready */
export const WPS = 2.5;

export function slideDuration(voiceSeconds) {
  return Math.max(MIN_SLIDE, LEAD + (voiceSeconds || 0) + TAIL);
}

export function slideDurations(voiceDurs) {
  return voiceDurs.map(slideDuration);
}

/** Start time of each slide; consecutive slides overlap by XFADE. */
export function timeline(durs) {
  const starts = [];
  let t = 0;
  for (const d of durs) {
    starts.push(t);
    t += d - XFADE;
  }
  return { starts, total: durs.length ? t + XFADE : 0 };
}

/** A guess at how long narration will take to speak, before it has been. */
export function estimateVoice(text, speed = 1) {
  const words = String(text || '').split(/\s+/).filter(Boolean).length;
  return words ? words / (WPS * (speed || 1)) : 0;
}

/** A narration's words, as written (split at spaces). Word timings use the same split. */
export function narrationWords(text) {
  return String(text ?? '').replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
}

/**
 * Subtitle lines for a slide's narration as ranges of word indexes [from, to):
 * about two lines of text each, ending at a sentence end where one comes.
 */
export function cueRanges(words) {
  const out = [];
  let from = 0;
  let len = 0;
  words.forEach((w, k) => {
    const next = len ? len + 1 + w.length : w.length;
    if (next > 84 && len) {
      out.push([from, k]);
      from = k;
      len = w.length;
    } else {
      len = next;
      if (/[.!?]$/.test(w) && len > 40) {
        out.push([from, k + 1]);
        from = k + 1;
        len = 0;
      }
    }
  });
  if (from < words.length) out.push([from, words.length]);
  return out;
}

/** Subtitle lines for a slide's narration (the export's SRT uses the same split). */
export function cues(text) {
  const words = narrationWords(text);
  return cueRanges(words).map(([a, b]) => words.slice(a, b).join(' '));
}

/**
 * When each word is spoken, for clips made before the server timed words:
 * spread over the clip by length, as the SRT does.
 */
export function estimateWordTimes(words, duration) {
  const total = words.reduce((n, w) => n + w.length + 1, 0) || 1;
  let t = 0;
  return words.map((w) => {
    const d = ((w.length + 1) / total) * duration;
    const span = [t, t + d];
    t += d;
    return span;
  });
}
