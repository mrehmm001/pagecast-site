// The PageCast player: plays a storyboard in the browser, drawing each slide with
// the same templates as the MP4 export and playing its narration on the export's
// timeline (shared/timeline.js). Narration can arrive while it plays: a slide whose
// clip isn't spoken yet holds with "Preparing narration…" until it is.
//
//   const player = new DeckPlayer(element, { cssHref, img });
//   player.load(deck, audio, { speed });   // audio: one entry per slide (below)
//   player.update(audio);                  // as more clips are ready
//
// An audio entry is { url, duration, timingsUrl } once spoken, { pending: true }
// until then, { silent: true } for a slide without narration, or { missing: true }
// when it couldn't be spoken (played silently). timingsUrl gives when each word is
// spoken, which highlights the subtitles word by word.
//
// Timing is driven by the narration itself while a clip plays (its currentTime),
// and by the animation clock in the silences between, so slides and speech can't
// drift apart. The scrubber seeks to any moment; times in slides whose narration
// isn't spoken yet are estimates until it is.
import { slideDocument, fitSlide, withCredits, W, H } from './slides.js';
import { LEAD, XFADE, slideDuration, estimateVoice, timeline, narrationWords, cueRanges, estimateWordTimes } from './timeline.js';

const KEN_BURNS = 0.07; // image-full slides zoom in by 7% over their length, as in the export
const STEP = 5; // seconds the arrow keys skip

const fmt = (s) => {
  s = Math.max(0, Math.floor(s));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};
const escapeHTML = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

const ICONS = {
  play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg>',
  pause: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor"/></svg>',
  prev: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5h2v14H6zM19 5.5v13L9.5 12z" fill="currentColor"/></svg>',
  next: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 5h2v14h-2zM5 5.5v13l9.5-6.5z" fill="currentColor"/></svg>',
  replay: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z" fill="currentColor"/></svg>',
  full: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h6v2H6v4H4zM14 4h6v6h-2V6h-4zM4 14h2v4h4v2H4zM18 14h2v6h-6v-2h4z" fill="currentColor"/></svg>',
};

export class DeckPlayer {
  constructor(root, { cssHref, img = () => null, autoplay = false, onState = () => {} } = {}) {
    this.root = root;
    this.cssHref = cssHref;
    this.img = img;
    this.autoplay = autoplay;
    this.onState = onState;
    this.deck = null;
    this.audio = [];
    this.speed = 1;
    this.captions = true;
    this.layers = new Map(); // slide index -> { frame, ready, loaded }
    this.clips = new Map(); // slide index -> HTMLAudioElement
    this.timings = new Map(); // slide index -> [[start, end] | null per word] once fetched
    this.reset();
    this.build();
    // Every frame while the player is on screen. Browsers stop frames in background
    // tabs and hidden or covered windows while the narration plays on, so a timer
    // keeps the clock going (a few times a second) whenever frames stop coming.
    const frame = (now) => {
      this.frame = requestAnimationFrame(frame);
      this.tick(now);
    };
    this.frame = requestAnimationFrame(frame);
    this.timer = setInterval(() => {
      const now = performance.now();
      if (this.last == null || now - this.last > 300) this.tick(now);
    }, 250);
  }

  reset() {
    this.i = 0;
    this.t = 0;
    this.playing = false;
    this.ended = false;
    this.waiting = false;
    this.voiceStarted = false;
    this.fade = null; // { from, t } while the previous slide fades out under the current one
    this.last = null;
    this.shown = {}; // what's on screen, so the DOM is only touched when it changes
  }

  // ------------------------------------------------------------------ DOM
  build() {
    this.root.classList.add('dp');
    this.root.tabIndex = 0;
    this.root.innerHTML = `
      <div class="dp-screen">
        <div class="dp-stage"></div>
        <div class="dp-sub hidden" aria-hidden="true"><span class="dp-line"></span></div>
        <div class="dp-wait hidden" role="status"><div class="dp-spin" aria-hidden="true"></div><span>Preparing narration…</span></div>
        <button class="dp-big" type="button" aria-label="Play">${ICONS.play}</button>
      </div>
      <div class="dp-controls">
        <button class="dp-btn" data-act="toggle" type="button" aria-label="Play" title="Play (space)">${ICONS.play}</button>
        <button class="dp-btn" data-act="prev" type="button" aria-label="Previous slide" title="Previous slide (Shift+←)">${ICONS.prev}</button>
        <button class="dp-btn" data-act="next" type="button" aria-label="Next slide" title="Next slide (Shift+→)">${ICONS.next}</button>
        <div class="dp-seek" role="slider" tabindex="0" aria-label="Seek" aria-valuemin="0">
          <div class="dp-track">
            <div class="dp-pending"></div>
            <div class="dp-fill"></div>
            <div class="dp-ticks"></div>
            <div class="dp-knob"></div>
          </div>
          <div class="dp-tip hidden"></div>
        </div>
        <span class="dp-time">0:00 / 0:00</span>
        <button class="dp-btn dp-cc on" data-act="cc" type="button" aria-label="Subtitles" aria-pressed="true" title="Subtitles (c)">CC</button>
        <button class="dp-btn" data-act="full" type="button" aria-label="Full screen" title="Full screen (f)">${ICONS.full}</button>
      </div>`;
    const q = (s) => this.root.querySelector(s);
    this.el = {
      screen: q('.dp-screen'),
      stage: q('.dp-stage'),
      sub: q('.dp-sub'),
      line: q('.dp-line'),
      wait: q('.dp-wait'),
      waitText: q('.dp-wait span'),
      big: q('.dp-big'),
      toggle: q('[data-act="toggle"]'),
      seek: q('.dp-seek'),
      track: q('.dp-track'),
      pending: q('.dp-pending'),
      fill: q('.dp-fill'),
      ticks: q('.dp-ticks'),
      knob: q('.dp-knob'),
      tip: q('.dp-tip'),
      time: q('.dp-time'),
      cc: q('[data-act="cc"]'),
    };
    this.root.addEventListener('click', (e) => {
      if (e.target.closest('.dp-seek')) return;
      const b = e.target.closest('[data-act], .dp-big');
      if (!b) {
        if (e.target.closest('.dp-screen')) this.toggle();
        return;
      }
      if (b.classList.contains('dp-big')) this.play();
      else ({ toggle: () => this.toggle(), prev: () => this.prev(), next: () => this.next(), cc: () => this.setCaptions(!this.captions), full: () => this.fullscreen() })[b.dataset.act]?.();
    });
    this.root.addEventListener('keydown', (e) => this.key(e));
    this.scrubber();
    this.resize = new ResizeObserver(() => this.fit());
    this.resize.observe(this.el.screen);
  }

  /** Click or drag anywhere on the bar to go to that moment; hovering shows the time and slide. */
  scrubber() {
    const seek = this.el.seek;
    const timeAt = (e) => {
      const r = this.el.track.getBoundingClientRect();
      return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * (this.times?.total || 0);
    };
    let resume = false;
    seek.addEventListener('pointerdown', (e) => {
      if (!this.deck || e.button !== 0) return;
      e.preventDefault();
      seek.setPointerCapture(e.pointerId);
      this.scrubbing = true;
      resume = this.playing || this.ended;
      this.pause();
      this.seekTime(timeAt(e));
      seek.focus();
    });
    seek.addEventListener('pointermove', (e) => {
      if (!this.deck) return;
      const t = timeAt(e);
      this.tip(e, t);
      if (this.scrubbing) this.seekTime(t);
    });
    const end = (e) => {
      if (!this.scrubbing) return;
      this.scrubbing = false;
      try {
        seek.releasePointerCapture(e.pointerId);
      } catch {}
      if (resume && !this.ended) this.play();
    };
    seek.addEventListener('pointerup', end);
    seek.addEventListener('pointercancel', end);
    seek.addEventListener('pointerleave', () => {
      if (!this.scrubbing) this.el.tip.classList.add('hidden');
    });
  }

  tip(e, t) {
    const r = this.el.track.getBoundingClientRect();
    const k = this.slideAt(t);
    this.el.tip.textContent = `${fmt(t)} · Slide ${k + 1}`;
    this.el.tip.classList.remove('hidden');
    const x = Math.max(0, Math.min(r.width, e.clientX - r.left));
    this.el.tip.style.left = `${x}px`;
  }

  fit() {
    const r = this.el.screen.getBoundingClientRect();
    const k = Math.min(r.width / W, r.height / H) || 0;
    this.el.stage.style.transform = `translate(-50%, -50%) scale(${k})`;
    // subtitles scale with the picture, as they would in the video
    this.el.sub.style.fontSize = `${Math.max(12, 38 * k)}px`;
  }

  key(e) {
    if (e.target.closest('input, textarea, select') || e.altKey || e.ctrlKey || e.metaKey) return;
    const now = this.now();
    const act = {
      ' ': () => this.toggle(),
      k: () => this.toggle(),
      ArrowRight: () => (e.shiftKey ? this.next() : this.seekTime(now + STEP)),
      ArrowLeft: () => (e.shiftKey ? this.prev() : this.seekTime(now - STEP)),
      Home: () => this.seekTime(0),
      End: () => this.seekTime(this.times.total),
      PageDown: () => this.next(),
      PageUp: () => this.prev(),
      f: () => this.fullscreen(),
      c: () => this.setCaptions(!this.captions),
    }[e.key];
    if (!act || !this.deck) return;
    e.preventDefault();
    act();
  }

  fullscreen() {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else this.root.requestFullscreen?.().catch(() => {});
  }

  setCaptions(on) {
    this.captions = on;
    this.el.cc.classList.toggle('on', on);
    this.el.cc.setAttribute('aria-pressed', String(on));
  }

  // ------------------------------------------------------------------ content
  load(deck, audio, { speed = 1 } = {}) {
    for (const a of this.clips.values()) a.pause();
    this.clips.clear();
    this.timings.clear();
    this.estimates = new Map();
    for (const l of this.layers.values()) l.frame.remove();
    this.layers.clear();
    // every video ends with the credits card (source, licence, made with AI), as exports do
    this.deck = withCredits(deck);
    this.speed = speed;
    this.words = this.deck.slides.map((s) => narrationWords(s.narration));
    this.cues = this.words.map((w) => cueRanges(w));
    this.reset();
    this.update(audio);
    this.fit();
    if (this.autoplay) this.play();
    this.draw();
  }

  update(audio) {
    // keep the playhead at the same moment of the same slide while estimates firm up
    // one entry per slide; the credits card (and anything else the caller doesn't know about) is silent
    this.audio = audio.slice();
    while (this.audio.length < this.deck.slides.length) this.audio.push({ silent: true });
    this.durs = this.deck.slides.map((s, i) => slideDuration(this.voiceLength(i)));
    this.times = timeline(this.durs);
    const total = this.times.total || 1;
    const pct = (x) => `${((x / total) * 100).toFixed(3)}%`;
    this.el.ticks.innerHTML = this.times.starts
      .slice(1)
      .map((s) => `<i style="left:${pct(s)}"></i>`)
      .join('');
    this.el.pending.innerHTML = this.audio
      .map((a, i) => (a?.pending ? `<i style="left:${pct(this.times.starts[i])};width:${pct(this.durs[i])}"></i>` : ''))
      .join('');
    this.el.seek.setAttribute('aria-valuemax', String(Math.round(total)));
    for (const [i, a] of this.audio.entries()) if (a?.timingsUrl && !this.timings.has(i)) this.fetchTimings(i, a.timingsUrl);
  }

  /** when each word of slide i is spoken; the subtitles estimate until it arrives */
  async fetchTimings(i, url) {
    this.timings.set(i, null);
    try {
      const res = await fetch(url);
      const info = res.ok ? await res.json() : null;
      if (Array.isArray(info?.words) && info.words.length === this.words[i].length) this.timings.set(i, info.words);
    } catch {
      // older clips have no word timings; the estimate stands in
    }
  }

  voiceLength(i) {
    const a = this.audio[i];
    if (a?.duration) return a.duration;
    if (a?.silent || a?.missing) return 0;
    return estimateVoice(this.deck.slides[i].narration, this.speed);
  }

  layer(i) {
    let l = this.layers.get(i);
    if (l) return l;
    const frame = document.createElement('iframe');
    frame.className = 'dp-layer';
    frame.tabIndex = -1;
    frame.setAttribute('aria-hidden', 'true');
    frame.title = `Slide ${i + 1}`;
    l = { frame, loaded: false };
    l.ready = new Promise((resolve) => {
      frame.addEventListener(
        'load',
        async () => {
          const doc = frame.contentDocument;
          try {
            await doc.fonts?.ready;
            await Promise.all([...doc.images].map((im) => (im.complete ? null : new Promise((r) => (im.onload = im.onerror = r)))));
            fitSlide(doc);
          } catch {}
          l.loaded = true;
          resolve();
        },
        { once: true },
      );
    });
    frame.srcdoc = slideDocument(this.deck.slides[i], this.deck, { img: this.img, index: i, total: this.deck.slides.length, cssHref: this.cssHref });
    this.el.stage.appendChild(frame);
    this.layers.set(i, l);
    return l;
  }

  /** keeps the slides around the current one drawn, and lets go of the rest */
  keepLayers() {
    const n = this.deck.slides.length;
    const want = new Set([this.i, this.i + 1, this.i + 2, this.fade?.from].filter((x) => x != null && x >= 0 && x < n));
    for (const i of want) this.layer(i);
    for (const [i, l] of this.layers) {
      if (!want.has(i) && Math.abs(i - this.i) > 3) {
        l.frame.remove();
        this.layers.delete(i);
      }
    }
  }

  clip(i) {
    const a = this.audio[i];
    if (!a?.url) return null;
    let el = this.clips.get(i);
    if (!el) {
      el = new Audio();
      el.preload = 'auto';
      el.src = a.url;
      this.clips.set(i, el);
    }
    return el;
  }

  /** whether slide i's narration is spoken (or it has none) */
  voiced(i) {
    const a = this.audio[i];
    return !!(a?.url || a?.silent || a?.missing);
  }

  /** whether slide i can start: drawn, and its narration ready */
  ready(i) {
    return this.layer(i).loaded && this.voiced(i);
  }

  /** whether slide i's clip should be sounding at time t into the slide */
  inVoice(i, t) {
    const d = this.audio[i]?.duration;
    return !!d && t >= LEAD && t - LEAD < d - 0.05;
  }

  /**
   * Moves a clip to `pos` seconds. A clip that hasn't loaded yet can't be moved
   * (the browser would start it from the beginning), so it moves once it has.
   */
  cueClip(a, pos) {
    pos = Math.max(0, pos);
    a.wantAt = pos;
    if (a.readyState >= 1) {
      a.currentTime = pos;
      return;
    }
    if (a.waitingForMetadata) return;
    a.waitingForMetadata = true;
    a.addEventListener(
      'loadedmetadata',
      () => {
        a.waitingForMetadata = false;
        a.currentTime = a.wantAt;
      },
      { once: true },
    );
  }

  speak(a) {
    a.play().catch((e) => {
      // the browser wants a click before sound plays: wait for one on the Play button
      if (e?.name === 'NotAllowedError') this.pause();
    });
  }

  // ------------------------------------------------------------------ transport
  /** where the playhead is on the whole timeline, in seconds */
  now() {
    return (this.times?.starts[this.i] ?? 0) + this.t;
  }

  /** the slide showing at time t (in a crossfade, the one fading in) */
  slideAt(t) {
    const s = this.times.starts;
    let k = 0;
    while (k + 1 < s.length && s[k + 1] <= t) k++;
    return k;
  }

  play() {
    if (!this.deck) return;
    if (this.ended) this.seekTime(0);
    this.playing = true;
    const a = this.voiceStarted ? this.clip(this.i) : null;
    if (a && this.inVoice(this.i, this.t)) {
      this.cueClip(a, this.t - LEAD);
      this.speak(a);
    }
    this.draw();
  }

  pause() {
    this.playing = false;
    for (const a of this.clips.values()) a.pause();
    this.draw();
  }

  toggle() {
    if (this.playing) this.pause();
    else this.play();
  }

  next() {
    if (this.deck && this.i < this.deck.slides.length - 1) this.seekTime(this.times.starts[this.i + 1]);
  }

  prev() {
    // back to the start of this slide first, as most players do
    if (this.t > 2 || this.i === 0) this.seekTime(this.times.starts[this.i]);
    else this.seekTime(this.times.starts[this.i - 1]);
  }

  /** go to slide i, from its start */
  seek(i) {
    this.seekTime(this.times.starts[Math.max(0, Math.min(i, this.deck.slides.length - 1))]);
  }

  /** go to any moment of the video */
  seekTime(time) {
    if (!this.deck) return;
    const total = this.times.total;
    time = Math.max(0, Math.min(time, total));
    for (const a of this.clips.values()) a.pause();
    const i = this.slideAt(time);
    let t = time - this.times.starts[i];
    // a moment inside a crossfade shows the previous slide fading out underneath
    this.fade = i > 0 && t < XFADE ? { from: i - 1, t: time - this.times.starts[i - 1] } : null;
    this.i = i;
    this.ended = time >= total && i === this.deck.slides.length - 1;
    if (this.ended) this.playing = false;
    this.waiting = false;
    this.voiceStarted = t >= LEAD;
    if (this.voiceStarted && !this.voiced(i)) {
      // not spoken yet: play on from just before the narration once it is
      this.voiceStarted = false;
      t = Math.min(t, LEAD);
    }
    this.t = t;
    const a = this.voiceStarted ? this.clip(i) : null;
    if (a) {
      this.cueClip(a, Math.min(t - LEAD, this.audio[i].duration));
      if (this.playing && this.inVoice(i, t)) this.speak(a);
    }
    this.draw();
  }

  destroy() {
    cancelAnimationFrame(this.frame);
    clearInterval(this.timer);
    this.resize.disconnect();
    for (const a of this.clips.values()) a.pause();
    this.clips.clear();
    this.root.innerHTML = '';
  }

  // ------------------------------------------------------------------ clock
  tick(now) {
    const dt = this.last == null ? 0 : Math.max(0, Math.min(1.5, (now - this.last) / 1000));
    this.last = Math.max(this.last ?? now, now);
    if (!this.deck) return;
    this.keepLayers();
    if (this.playing) this.advance(dt);
    this.draw();
  }

  advance(dt) {
    const n = this.deck.slides.length;
    const i = this.i;
    this.waiting = false;
    if (!this.layer(i).loaded) {
      this.waiting = true;
      return;
    }
    const a = this.clip(i);
    // a clip that is still loading at the moment it was moved to: hold until it plays
    if (this.voiceStarted && a?.waitingForMetadata) return;
    const speaking = this.voiceStarted && a && !a.paused && !a.ended;
    // while a clip plays it sets the time; in the silences, the frame clock does
    let t = speaking ? LEAD + a.currentTime : this.t + dt;

    if (this.fade) {
      this.fade.t += dt;
      if (this.fade.t >= this.durs[this.fade.from]) this.fade = null;
    }

    if (!this.voiceStarted && t >= LEAD) {
      if (!this.voiced(i)) {
        // hold just before the narration until it's spoken
        this.waiting = true;
        this.t = LEAD;
        return;
      }
      this.voiceStarted = true;
      if (a) {
        this.cueClip(a, t - LEAD);
        this.speak(a);
      }
    }

    const end = this.durs[i];
    if (i < n - 1 && t >= end - XFADE) {
      if (!this.ready(i + 1)) {
        this.waiting = true;
        this.t = end - XFADE;
        return;
      }
      this.fade = { from: i, t };
      this.i = i + 1;
      this.t = t - (end - XFADE);
      this.voiceStarted = false;
      return;
    }
    if (i === n - 1 && t >= end) {
      t = end;
      this.playing = false;
      this.ended = true;
    }
    this.t = t;
  }

  // ------------------------------------------------------------------ drawing
  /** the subtitle line and word being spoken at time t into slide i */
  subtitle(i, t) {
    const d = this.audio[i]?.duration;
    if (!this.captions || !this.voiceStarted || !d) return null;
    const at = t - LEAD;
    if (at < 0 || at > d + 0.3) return null;
    const words = this.words[i];
    if (!this.timings.get(i) && !this.estimates.has(i)) this.estimates.set(i, estimateWordTimes(words, d));
    const times = this.timings.get(i) || this.estimates.get(i);
    // the word being said: the last one that has started
    let word = -1;
    for (let k = 0; k < words.length; k++) {
      if (times[k] && times[k][0] <= at) word = k;
    }
    if (word < 0) word = 0;
    const cue = this.cues[i].findIndex(([a, b]) => word >= a && word < b);
    const spoken = !!times[word] && at <= times[word][1] + 0.15;
    return { cue: Math.max(0, cue), word, spoken };
  }

  drawSubtitle() {
    const i = this.i;
    const s = this.subtitle(i, this.t);
    const key = s ? `${i}:${s.cue}` : '';
    if (key !== this.shown.cue) {
      this.shown.cue = key;
      this.shown.word = null;
      if (s) {
        const [a, b] = this.cues[i][s.cue];
        this.el.line.innerHTML = this.words[i]
          .slice(a, b)
          .map((w, k) => `<span class="dp-w" data-k="${a + k}">${escapeHTML(w)}</span>`)
          .join(' ');
      }
      this.el.sub.classList.toggle('hidden', !s);
    }
    if (!s) return;
    const word = s.spoken ? s.word : s.word + 0.5; // between words, nothing is lit
    if (word === this.shown.word) return;
    this.shown.word = word;
    for (const span of this.el.line.children) {
      const k = Number(span.dataset.k);
      span.classList.toggle('said', k < word);
      span.classList.toggle('now', k === word);
    }
  }

  draw() {
    if (!this.deck) return;
    const i = this.i;
    for (const [k, l] of this.layers) {
      const shown = l.loaded && (k === i || k === this.fade?.from);
      l.frame.classList.toggle('shown', shown);
      if (!shown) continue;
      const t = k === i ? this.t : this.fade.t;
      const slide = this.deck.slides[k];
      const zoom = slide.layout === 'image-full' ? 1 + (KEN_BURNS * Math.min(t, this.durs[k])) / this.durs[k] : 1;
      l.frame.style.transform = `scale(${zoom})`;
      // the new slide fades in over the old one, as ffmpeg's xfade does
      l.frame.style.opacity = k === i && this.fade ? String(Math.min(1, this.t / XFADE)) : '1';
      l.frame.style.zIndex = k === i ? '2' : '1';
    }

    this.drawSubtitle();

    const waiting = this.playing && this.waiting;
    this.el.wait.classList.toggle('hidden', !waiting);
    if (waiting) this.el.waitText.textContent = this.layers.get(this.voiceStarted ? i + 1 : i)?.loaded ? 'Preparing narration…' : 'Loading…';
    const mode = `${this.playing ? 'playing' : this.ended ? 'ended' : 'paused'}${this.scrubbing ? '/scrubbing' : ''}`;
    if (mode !== this.shown.mode) {
      this.shown.mode = mode;
      this.el.big.classList.toggle('hidden', this.playing || this.scrubbing);
      this.el.big.innerHTML = this.ended ? ICONS.replay : ICONS.play;
      this.el.big.setAttribute('aria-label', this.ended ? 'Play again' : 'Play');
      this.el.toggle.innerHTML = this.playing ? ICONS.pause : ICONS.play;
      this.el.toggle.setAttribute('aria-label', this.playing ? 'Pause' : 'Play');
    }

    const now = this.now();
    const total = this.times.total;
    const text = `${fmt(now)} / ${fmt(total)}`;
    if (this.el.time.textContent !== text) {
      this.el.time.textContent = text;
      this.el.seek.setAttribute('aria-valuenow', String(Math.floor(now)));
      this.el.seek.setAttribute('aria-valuetext', `${fmt(now)} of ${fmt(total)}, slide ${i + 1} of ${this.deck.slides.length}`);
    }
    const f = `${(total ? Math.min(1, now / total) * 100 : 0).toFixed(3)}%`;
    this.el.fill.style.width = f;
    this.el.knob.style.left = f;

    const state = `${i}|${this.playing}|${waiting}|${this.ended}`;
    if (state !== this.lastState) {
      this.lastState = state;
      this.onState({ index: i, total: this.deck.slides.length, playing: this.playing, waiting, ended: this.ended });
    }
  }
}
