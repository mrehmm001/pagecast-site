// Service worker: shows the finished video as a modal over the page it was made
// from, and opens the player in its own window when a page blocks the modal.

async function waitForComplete(tabId) {
  const t = await chrome.tabs.get(tabId);
  if (t.status === 'complete') return;
  await new Promise((resolve) => {
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    }, 20000);
  });
}

const sameDoc = (a, b) => {
  try {
    const x = new URL(a);
    const y = new URL(b);
    return x.origin + x.pathname + x.search === y.origin + y.pathname + y.search;
  } catch {
    return false;
  }
};

async function showVideo({ tabId, url, videoKey = 'last' }) {
  let tab = null;
  try { tab = await chrome.tabs.get(tabId); } catch {}
  // the original tab is gone or has moved on: reopen the page the video was made from
  if (!tab || (url && !sameDoc(tab.url, url))) {
    tab = await chrome.tabs.create({ url, active: true });
  }
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  await waitForComplete(tab.id);
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (key) => { window.__pagecastVideoKey = key; },
    args: [videoKey],
  });
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/modal.js'] });
  return { tabId: tab.id };
}

async function openPlayerWindow(videoKey = 'last') {
  await chrome.windows.create({
    url: chrome.runtime.getURL(`player.html?video=${encodeURIComponent(videoKey)}`),
    type: 'popup',
    width: 1100,
    height: 720,
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'showVideo') {
    showVideo(msg).then(sendResponse, (e) => sendResponse({ error: e.message }));
    return true;
  }
  if (msg?.type === 'openPlayerWindow') {
    openPlayerWindow(msg.videoKey).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === 'openStoryboard' && msg.jobKey) {
    chrome.tabs.create({ url: chrome.runtime.getURL(`storyboard.html?job=${encodeURIComponent(msg.jobKey)}`) }).then(() => sendResponse({ ok: true }));
    return true;
  }
  return false;
});
